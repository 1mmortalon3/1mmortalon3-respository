--[[

Author: tochnonement
Email: tochnonement@gmail.com

03/01/2024

--]]

netchunk.Register('onyx.f4:SendStats')