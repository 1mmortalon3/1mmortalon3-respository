--[[

Author: tochnonement
Email: tochnonement@gmail.com

19/03/2024

--]]

netchunk.Register('onyx.scoreboard:SyncBrickGangs')