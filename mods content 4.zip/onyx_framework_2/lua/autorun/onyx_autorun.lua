--[[

Author: tochnonement
Email: tochnonement@gmail.com

05/06/2022

--]]

onyx = {}
onyx.cfg = {}

AddCSLuaFile('onyx/util.lua')
include('onyx/util.lua')
AddCSLuaFile('onyx/init.lua')
include('onyx/init.lua')