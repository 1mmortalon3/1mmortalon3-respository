if SAM_LOADED then return end

return {
	--
	-- Enable MySQL/sqlite
	-- Don't touch this if you don't know what it means
	--
	MySQL = false,

	--
	-- MySQL host/ip
	--
	Host = "YOUR HOST/IP",

	--
	-- MySQL username
	--
	Username = "YOUR USERNAME",

	--
	-- MySQL password
	--
	Password = "YOUR PASSWORD",

	--
	-- MySQL database
	--
	Database = "YOUR DATABASE NAME",
}