-----Clone Trooper
TEAM_CT = DarkRP.createJob("Clone Trooper", { -- Name
    color = Color(211, 219, 222, 255), -- Team color
    model = "models/aussiwozzi/cgi/base/unassigned_trp.mdl", -- Player model
    description = [[Clone Trooper]],  -- Job description
    weapons = {"rw_sw_dc15a","rw_sw_dc15s","rw_sw_dc17ext"}, -- Additional weapons
    command = "CT", -- Command to become the job
    max = 0, -- Maximum amount of said job
    salary = 300, -- Salary
    admin = 0, -- Requires Admin? 1 for yes, 0 for no.
    vote = false, -- Do they need to vote? true for yes, false for no.
    sortOrder = 2;
	PlayerSpawn = function(ply) ply:SetHealth(300) ply:SetMaxHealth(300) ply:SetArmor(300) ply:SetMaxArmor(300) end,
	hasLicense = true, -- Has a license
	category = "Clone Trooper",
})
------Clone Recruit
TEAM_CR= DarkRP.createJob("Clone Recruit", { -- Name
    color = Color(211, 219, 222, 255), -- Team color
    model = "models/cadet_red/pm_training_cadet_bravo.mdl", -- Player model
    description = [[Clone Recruit]],  -- Job description
    weapons = {"rw_sw_trd_dc15a","rw_sw_trd_dc15s","rw_sw_trd_dc17"}, -- Additional weapons
    command = "CR", -- Command to become the job
    max = 0, -- Maximum amount of said job
    salary = 300, -- Salary
    admin = 0, -- Requires Admin? 1 for yes, 0 for no.
    vote = false, -- Do they need to vote? true for yes, false for no.
    sortOrder = 0;
	PlayerSpawn = function(ply) ply:SetHealth(300) ply:SetMaxHealth(300) ply:SetArmor(300) ply:SetMaxArmor(300) end,
	hasLicense = true, -- Has a license
	category = "Clone Recruit",
})
-----501st Legion
TEAM_501ST = DarkRP.createJob("501st Legion Trooper", { -- Name
    color = Color(211, 219, 222, 255), -- Team color
    model = "models/aussiwozzi/cgi/base/501st_trooper.mdl", -- Player model
    description = [[501st Legion]],  -- Job description
    weapons = {"rw_sw_dc15a","rw_sw_dc17ext","rw_sw_dc15s"}, -- Additional weapons
    command = "501stTPR", -- Command to become the job
    max = 0, -- Maximum amount of said job
    salary = 350, -- Salary
    admin = 0, -- Requires Admin? 1 for yes, 0 for no.
    vote = false, -- Do they need to vote? true for yes, false for no.
    sortOrder = 3;
	PlayerSpawn = function(ply) ply:SetHealth(300) ply:SetMaxHealth(300) ply:SetArmor(300) ply:SetMaxArmor(300) end,
	hasLicense = false, -- Has a license
	category = "501st Legion",
	

})
TEAM_501ST = DarkRP.createJob("Commander Rex", { -- Name
    color = Color(211, 219, 222, 255), -- Team color
    model = "models/aussiwozzi/cgi/base/501st_rex.mdl", -- Player model
    description = [[501st Legion]],  -- Job description
    weapons = {"rw_sw_dc15a","rw_sw_dc15s","rw_sw_dual_dc17ext","weapon_bactainjector",'weapon_bactanade'}, -- Additional weapons
    command = "501stCMDR", -- Command to become the job
    max = 1, -- Maximum amount of said job
    salary = 350, -- Salary
    admin = 0, -- Requires Admin? 1 for yes, 0 for no.
    vote = false, -- Do they need to vote? true for yes, false for no.
    sortOrder = 3;
	PlayerSpawn = function(ply) ply:SetHealth(500) ply:SetMaxHealth(500) ply:SetArmor(300) ply:SetMaxArmor(300) end,
	hasLicense = false, -- Has a license
	category = "501st Legion",
	

})
TEAM_501ST = DarkRP.createJob("501st Legion ARC", { -- Name
    color = Color(211, 219, 222, 255), -- Team color
    model = "models/aussiwozzi/cgi/base/501st_arc.mdl", -- Player model
    description = [[501st Legion]],  -- Job description
    weapons = {"rw_sw_dual_dc17ext","rw_sw_westarm5","realistic_hook"}, -- Additional weapons
    command = "501stARC", -- Command to become the job
    max = 3, -- Maximum amount of said job
    salary = 350, -- Salary
    admin = 0, -- Requires Admin? 1 for yes, 0 for no.
    vote = false, -- Do they need to vote? true for yes, false for no.
    sortOrder = 3;
	PlayerSpawn = function(ply) ply:SetHealth(450) ply:SetMaxHealth(450) ply:SetArmor(300) ply:SetMaxArmor(300) end,
	hasLicense = false, -- Has a license
	category = "501st Legion",
	
})
TEAM_501ST = DarkRP.createJob("501st Legion ARF", { -- Name
    color = Color(211, 219, 222, 255), -- Team color
    model = "models/aussiwozzi/cgi/base/501st_arf.mdl", -- Player model
    description = [[501st Legion]],  -- Job description
    weapons = {"rw_sw_dc15x","rw_sw_dc17ext","rw_sw_dc15s","realistic_hook"}, -- Additional weapons
    command = "501stARF", -- Command to become the job
    max = 5, -- Maximum amount of said job
    salary = 350, -- Salary
    admin = 0, -- Requires Admin? 1 for yes, 0 for no.
    vote = false, -- Do they need to vote? true for yes, false for no.
    sortOrder = 3;
	PlayerSpawn = function(ply) ply:SetHealth(300) ply:SetMaxHealth(300) ply:SetArmor(300) ply:SetMaxArmor(300) end,
	hasLicense = false, -- Has a license
	category = "501st Legion",
})
TEAM_501ST = DarkRP.createJob("501st Legion Heavy", { -- Name
    color = Color(211, 219, 222, 255), -- Team color
    model = "models/aussiwozzi/cgi/base/501st_torrent_officer.mdl", -- Player model
    description = [[501st Legion]],  -- Job description
    weapons = {"rw_sw_dc17ext","rw_sw_z6"}, -- Additional weapons
    command = "501stHVY", -- Command to become the job
    max = 5, -- Maximum amount of said job
    salary = 350, -- Salary
    admin = 0, -- Requires Admin? 1 for yes, 0 for no.
    vote = false, -- Do they need to vote? true for yes, false for no.
    sortOrder = 3;
	PlayerSpawn = function(ply) ply:SetHealth(300) ply:SetMaxHealth(300) ply:SetArmor(300) ply:SetMaxArmor(300) end,
	hasLicense = false, -- Has a license
	category = "501st Legion",
	

})
TEAM_501ST = DarkRP.createJob("501st Legion Jet Trooper", { -- Name
    color = Color(211, 219, 222, 255), -- Team color
    model = "models/aussiwozzi/cgi/base/501st_jet_trooper.mdl", -- Player model
    description = [[501st Legion]],  -- Job description
    weapons = {"rw_sw_dc15a","rw_sw_dc17ext","rw_sw_dp23","weapon_lvsrepair","alydus_fortificationbuildertablet"}, -- Additional weapons
    command = "501stENG", -- Command to become the job
    max = 5, -- Maximum amount of said job
    salary = 350, -- Salary
    admin = 0, -- Requires Admin? 1 for yes, 0 for no.
    vote = false, -- Do they need to vote? true for yes, false for no.
    sortOrder = 3;
	PlayerSpawn = function(ply) ply:SetHealth(300) ply:SetMaxHealth(300) ply:SetArmor(300) ply:SetMaxArmor(300) end,
	hasLicense = false, -- Has a license
	category = "501st Legion",
	

})
TEAM_501ST = DarkRP.createJob("501st Legion Medic", { -- Name
    color = Color(211, 219, 222, 255), -- Team color
    model = "models/aussiwozzi/cgi/base/501st_medic.mdl", -- Player model
    description = [[501st Legion]],  -- Job description
    weapons = {"rw_sw_dc15a","rw_sw_dc17ext","rw_sw_dc15s","weapon_bactainjector",'weapon_bactanade',"weapon_ncs_defib"}, -- Additional weapons
    command = "501stMED", -- Command to become the job
    max = 5, -- Maximum amount of said job
    salary = 350, -- Salary
    admin = 0, -- Requires Admin? 1 for yes, 0 for no.
    vote = false, -- Do they need to vote? true for yes, false for no.
    sortOrder = 3;
	PlayerSpawn = function(ply) ply:SetHealth(300) ply:SetMaxHealth(300) ply:SetArmor(300) ply:SetMaxArmor(300) end,
	hasLicense = false, -- Has a license
	category = "501st Legion",
	

})

-----104th Mechanized Batallion
TEAM_104TH = DarkRP.createJob("Commander Wolffe", { -- Name
    color = Color(211, 219, 222, 255), -- Team color
    model = "models/aussiwozzi/cgi/base/104th_wolffe.mdl", -- Player model
    description = [[104th Batallion]],  -- Job description
    weapons = {"rw_sw_dc15a","rw_sw_dc17ext","rw_sw_dc15s","weapon_bactainjector",'weapon_bactanade',"weapon_lvsrepair","weapon_ncs_defib"}, -- Additional weapons
    command = "104thCMDR", -- Command to become the job
    max = 1, -- Maximum amount of said job
    salary = 500, -- Salary
    admin = 0, -- Requires Admin? 1 for yes, 0 for no.
    vote = false, -- Do they need to vote? true for yes, false for no.
    sortOrder = 6;
	PlayerSpawn = function(ply) ply:SetHealth(500) ply:SetMaxHealth(300) ply:SetArmor(300) ply:SetMaxArmor(300) end,
	hasLicense = false, -- Has a license
	category = "104th Mechanized",
	

})
TEAM_104TH = DarkRP.createJob("104th Trooper", { -- Name
    color = Color(211, 219, 222, 255), -- Team color
    model = "models/aussiwozzi/cgi/base/104th_trooper.mdl", -- Player model
    description = [[104th Batallion]],  -- Job description
    weapons = {"rw_sw_dc15a","rw_sw_dc17ext","rw_sw_dc15s","weapon_lvsrepair"}, -- Additional weapons
    command = "104thTPR", -- Command to become the job
    max = 0, -- Maximum amount of said job
    salary = 350, -- Salary
    admin = 0, -- Requires Admin? 1 for yes, 0 for no.
    vote = false, -- Do they need to vote? true for yes, false for no.
    sortOrder = 6;
	PlayerSpawn = function(ply) ply:SetHealth(300) ply:SetMaxHealth(300) ply:SetArmor(300) ply:SetMaxArmor(300) end,
	hasLicense = false, -- Has a license
	category = "104th Mechanized",
	

})
TEAM_104TH = DarkRP.createJob("104th Heavy Trooper", { -- Name
    color = Color(211, 219, 222, 255), -- Team color
    model = "models/aussiwozzi/cgi/base/104th_evo.mdl", -- Player model
    description = [[104th Batallion]],  -- Job description
    weapons = {"rw_sw_z6","rw_sw_dc17ext","weapon_lvsrepair"}, -- Additional weapons
    command = "104thHVY", -- Command to become the job
    max = 5, -- Maximum amount of said job
    salary = 350, -- Salary
    admin = 0, -- Requires Admin? 1 for yes, 0 for no.
    vote = false, -- Do they need to vote? true for yes, false for no.
    sortOrder = 6;
	PlayerSpawn = function(ply) ply:SetHealth(300) ply:SetMaxHealth(300) ply:SetArmor(300) ply:SetMaxArmor(300) end,
	hasLicense = false, -- Has a license
	category = "104th Mechanized",
	

})
TEAM_104TH = DarkRP.createJob("104th Medic Trooper", { -- Name
    color = Color(211, 219, 222, 255), -- Team color
    model = "models/aussiwozzi/cgi/base/104th_medic.mdl", -- Player model
    description = [[104th Batallion]],  -- Job description
    weapons = {"rw_sw_dc15a","rw_sw_dc17ext","rw_sw_dc15s","weapon_bactainjector",'weapon_bactanade',"weapon_lvsrepair","weapon_ncs_defib"}, -- Additional weapons
    command = "104thMED", -- Command to become the job
    max = 5, -- Maximum amount of said job
    salary = 350, -- Salary
    admin = 0, -- Requires Admin? 1 for yes, 0 for no.
    vote = false, -- Do they need to vote? true for yes, false for no.
    sortOrder = 6;
	PlayerSpawn = function(ply) ply:SetHealth(300) ply:SetMaxHealth(300) ply:SetArmor(300) ply:SetMaxArmor(300) end,
	hasLicense = false, -- Has a license
	category = "104th Mechanized",
})
TEAM_104th = DarkRP.createJob("104th Mechanized Jet Trooper", { -- Name
    color = Color(211, 219, 222, 255), -- Team color
    model = "models/aussiwozzi/cgi/base/104th_jet.mdl", -- Player model
    description = [[104th Batallion]],  -- Job description
    weapons = {"rw_sw_dc15a","rw_sw_dc17ext","rw_sw_dp23","jet_mk5"}, -- Additional weapons
    command = "104thJET", -- Command to become the job
    max = 5, -- Maximum amount of said job
    salary = 350, -- Salary
    admin = 0, -- Requires Admin? 1 for yes, 0 for no.
    vote = false, -- Do they need to vote? true for yes, false for no.
    sortOrder = 6;
	PlayerSpawn = function(ply) ply:SetHealth(300) ply:SetMaxHealth(300) ply:SetArmor(300) ply:SetMaxArmor(300) end,
	hasLicense = false, -- Has a license
	category = "104th Mechanized",
	

})
TEAM_104th = DarkRP.createJob("104th Mechanized Engineer", { -- Name
    color = Color(211, 219, 222, 255), -- Team color
    model = "models/aussiwozzi/cgi/base/104th_jet.mdl", -- Player model
    description = [[104th Batallion]],  -- Job description
    weapons = {"rw_sw_dc15a","rw_sw_dc17ext","rw_sw_dc15s","rw_sw_dp23","weapon_lvsrepair","alydus_fortificationbuildertablet"}, -- Additional weapons
    command = "104thENG", -- Command to become the job
    max = 5, -- Maximum amount of said job
    salary = 350, -- Salary
    admin = 0, -- Requires Admin? 1 for yes, 0 for no.
    vote = false, -- Do they need to vote? true for yes, false for no.
    sortOrder = 6;
	PlayerSpawn = function(ply) ply:SetHealth(300) ply:SetMaxHealth(300) ply:SetArmor(300) ply:SetMaxArmor(300) end,
	hasLicense = false, -- Has a license
	category = "104th Mechanized",
	

})
-----Coruscant Guard
TEAM_CG = DarkRP.createJob("Coruscant Guard Medic", { -- Name
    color = Color(211, 219, 222, 255), -- Team color
    model = "models/aussiwozzi/cgi/base/cg_medic.mdl", -- Player model
    description = [[become a Coruscant Guard Medic]],  -- Job description
    weapons = {"rw_sw_dc15a","rw_sw_dc17ext","rw_sw_dc15s","weapon_bactainjector","weapon_bactanade","weapon_policebaton","weapon_ncs_defib"}, -- Additional weapons
    command = "CGMEDIC", -- Command to become the job
    max = 2, -- Maximum amount of said job
    salary = 350, -- Salary
    admin = 0, -- Requires Admin? 1 for yes, 0 for no.
    vote = false, -- Do they need to vote? true for yes, false for no.
    sortOrder = 8;
	PlayerSpawn = function(ply) ply:SetHealth(300) ply:SetMaxHealth(300) ply:SetArmor(300) ply:SetMaxArmor(300) end,
	hasLicense = false, -- Has a license
	category = "Coruscant Guard",
	

})
TEAM_CG = DarkRP.createJob("Coruscant Guard Trooper", { -- Name
    color = Color(211, 219, 222, 255), -- Team color
    model = "models/aussiwozzi/cgi/base/cg_trooper.mdl", -- Player model
    description = [[become a Coruscant Guard Trooper]],  -- Job description
    weapons = {"rw_sw_dc15a","rw_sw_dc17ext","rw_sw_dc15s","weapon_policebaton"}, -- Additional weapons
    command = "CGTPR", -- Command to become the job
    max = 2, -- Maximum amount of said job
    salary = 350, -- Salary
    admin = 0, -- Requires Admin? 1 for yes, 0 for no.
    vote = false, -- Do they need to vote? true for yes, false for no.
    sortOrder = 8;
	PlayerSpawn = function(ply) ply:SetHealth(300) ply:SetMaxHealth(300) ply:SetArmor(300) ply:SetMaxArmor(300)  end,
	hasLicense = false, -- Has a license
	category = "Coruscant Guard",
	

})
TEAM_CG = DarkRP.createJob("Commander Fox", { -- Name
    color = Color(211, 219, 222, 255), -- Team color
    model = "models/aussiwozzi/cgi/base/cg_fox.mdl", -- Player model
    description = [[become the Coruscant Guard Commander]],  -- Job description
    weapons = {"rw_sw_dc15a","rw_sw_dc17ext","rw_sw_dc15s","weapon_bactainjector","weapon_bactanade","weapon_policebaton","weapon_ncs_defib"}, -- Additional weapons
    command = "CGCMDR", -- Command to become the job
    max = 1, -- Maximum amount of said job
    salary = 500, -- Salary
    admin = 0, -- Requires Admin? 1 for yes, 0 for no.
    vote = false, -- Do they need to vote? true for yes, false for no.
    sortOrder = 8;
	PlayerSpawn = function(ply) ply:SetHealth(500) ply:SetMaxHealth(500) ply:SetArmor(300) ply:SetMaxArmor(300) end,
	hasLicense = false, -- Has a license
	category = "Coruscant Guard",
	

})
TEAM_CG = DarkRP.createJob("Coruscant Guard ARC", { -- Name
    color = Color(211, 219, 222, 255), -- Team color
    model = "models/aussiwozzi/cgi/base/cg_arc.mdl", -- Player model
    description = [[become a Coruscant Guard hound Member]],  -- Job description
    weapons = {"rw_sw_westarm5","rw_sw_dp23","rw_sw_stun_dc17","weapon_policebaton"}, -- Additional weapons
    command = "CGARC", -- Command to become the job
    max =2, -- Maximum amount of said job
    salary = 400, -- Salary
    admin = 0, -- Requires Admin? 1 for yes, 0 for no.
    vote = false, -- Do they need to vote? true for yes, false for no.
    sortOrder = 8;
	PlayerSpawn = function(ply) ply:SetHealth(450) ply:SetMaxHealth(450) ply:SetArmor(300) ply:SetMaxArmor(300) end,
	hasLicense = false, -- Has a license
	category = "Coruscant Guard",
	

})
TEAM_CG = DarkRP.createJob("Coruscant Guard Thorn", { -- Name
    color = Color(211, 219, 222, 255), -- Team color
    model = "models/aussiwozzi/cgi/base/cg_thorn.mdl", -- Player model
    description = [[become Coruscant Guard Thorn]],  -- Job description
    weapons = {"rw_sw_z6","rw_sw_dc15a","rw_sw_dc17ext","rw_sw_dc15s","weapon_policebaton"}, -- Additional weapons
    command = "CGTHO", -- Command to become the job
    max = 1, -- Maximum amount of said job
    salary = 350, -- Salary
    admin = 0, -- Requires Admin? 1 for yes, 0 for no.
    vote = false, -- Do they need to vote? true for yes, false for no.
    sortOrder = 8;
	PlayerSpawn = function(ply) ply:SetHealth(300) ply:SetMaxHealth(300) ply:SetArmor(300) ply:SetMaxArmor(300)  end,
	hasLicense = false, -- Has a license
	category = "Coruscant Guard",
	

})
TEAM_CG = DarkRP.createJob("Coruscant Guard Thire", { -- Name
    color = Color(211, 219, 222, 255), -- Team color
    model = "models/aussiwozzi/cgi/base/cg_thire.mdl", -- Player model
    description = [[become Coruscant Guard Thire]],  -- Job description
    weapons = {"rw_sw_dp23","rw_sw_dc15a","rw_sw_dc17ext","rw_sw_dc15s","weapon_policebaton"}, -- Additional weapons
    command = "CGTHI", -- Command to become the job
    max = 1, -- Maximum amount of said job
    salary = 350, -- Salary
    admin = 0, -- Requires Admin? 1 for yes, 0 for no.
    vote = false, -- Do they need to vote? true for yes, false for no.
    sortOrder = 8;
	PlayerSpawn = function(ply) ply:SetHealth(300) ply:SetMaxHealth(300) ply:SetArmor(300) ply:SetMaxArmor(300) end,
	hasLicense = false, -- Has a license
	category = "Coruscant Guard",
	

})
------ 212th Attack Batallion
TEAM_212TH = DarkRP.createJob("212th Trooper", { -- Name
    color = Color(211, 219, 222, 255), -- Team color
    model = "models/aussiwozzi/cgi/base/212th_trooper.mdl", -- Player model
    description = [[212th Attack Batallion]],  -- Job description
    weapons = {"rw_sw_dc15a","rw_sw_dc17ext","rw_sw_dc15s"}, -- Additional weapons
    command = "212thTPR", -- Command to become the job
    max = 0, -- Maximum amount of said job
    salary = 350, -- Salary
    admin = 0, -- Requires Admin? 1 for yes, 0 for no.
    vote = false, -- Do they need to vote? true for yes, false for no.
    sortOrder = 4;
	PlayerSpawn = function(ply) ply:SetHealth(300) ply:SetMaxHealth(300) ply:SetArmor(300) ply:SetMaxArmor(300) end,
	hasLicense = true, -- Has a license
	category = "212th Attack",

})
TEAM_212TH = DarkRP.createJob("212th Arc", { -- Name
    color = Color(211, 219, 222, 255), -- Team color
    model = "models/aussiwozzi/cgi/base/212th_arc.mdl", -- Player model
    description = [[212th Attack Batallion]],  -- Job description
    weapons = {"rw_sw_westarm5","rw_sw_dual_dc17ext","climb_swep2","realistic_hook"}, -- Additional weapons
    command = "212thARC", -- Command to become the job
    max = 3, -- Maximum amount of said job
    salary = 350, -- Salary
    admin = 0, -- Requires Admin? 1 for yes, 0 for no.
    vote = false, -- Do they need to vote? true for yes, false for no.
    sortOrder = 4;
	PlayerSpawn = function(ply) ply:SetHealth(300) ply:SetMaxHealth(300) ply:SetArmor(300) ply:SetMaxArmor(300) end,
	hasLicense = true, -- Has a license
	category = "212th Attack",

})
TEAM_212TH = DarkRP.createJob("Commander Cody", { -- Name
    color = Color(211, 219, 222, 255), -- Team color
    model = "models/aussiwozzi/cgi/base/212th_cody.mdl", -- Player model
    description = [[212th Attack Batallion]],  -- Job description
    weapons = {"rw_sw_dc15a_o","rw_sw_dc17ext","rw_sw_dc15s","weapon_bactainjector",'weapon_bactanade',"jet_mk5","weapon_ncs_defib"}, -- Additional weapons
    command = "212thCMDR", -- Command to become the job
    max = 1, -- Maximum amount of said job
    salary = 500, -- Salary
    admin = 0, -- Requires Admin? 1 for yes, 0 for no.
    vote = false, -- Do they need to vote? true for yes, false for no.
    sortOrder = 4;
	PlayerSpawn = function(ply) ply:SetHealth(500) ply:SetMaxHealth(500) ply:SetArmor(300) ply:SetMaxArmor(300) end,
	hasLicense = true, -- Has a license
	category = "212th Attack",

})
TEAM_212TH = DarkRP.createJob("212th Heavy", { -- Name
    color = Color(211, 219, 222, 255), -- Team color
    model = "models/aussiwozzi/cgi/base/212th_ghost_company.mdl", -- Player model
    description = [[212th Attack Batallion]],  -- Job description
    weapons = {"rw_sw_dc17ext","rw_sw_z6"}, -- Additional weapons
    command = "212thHVY", -- Command to become the job
    max = 5, -- Maximum amount of said job
    salary = 350, -- Salary
    admin = 0, -- Requires Admin? 1 for yes, 0 for no.
    vote = false, -- Do they need to vote? true for yes, false for no.
    sortOrder = 4;
	PlayerSpawn = function(ply) ply:SetHealth(300) ply:SetMaxHealth(300) ply:SetArmor(300) ply:SetMaxArmor(300) end,
	hasLicense = true, -- Has a license
	category = "212th Attack",

})
TEAM_212TH = DarkRP.createJob("212th ARF", { -- Name
    color = Color(211, 219, 222, 255), -- Team color
    model = "models/aussiwozzi/cgi/base/212th_arf.mdl", -- Player model
    description = [[212th Attack Batallion]],  -- Job description
    weapons = {"rw_sw_dc17ext","rw_sw_dc15s","rw_sw_dc15le_o","realistic_hook"}, -- Additional weapons
    command = "212thSUP", -- Command to become the job
    max = 5, -- Maximum amount of said job
    salary = 350, -- Salary
    admin = 0, -- Requires Admin? 1 for yes, 0 for no.
    vote = false, -- Do they need to vote? true for yes, false for no.
    sortOrder = 4;
	PlayerSpawn = function(ply) ply:SetHealth(300) ply:SetMaxHealth(300) ply:SetArmor(300) ply:SetMaxArmor(300) end,
	hasLicense = true, -- Has a license
	category = "212th Attack",

})
TEAM_212TH = DarkRP.createJob("212th Jet Trooper", { -- Name
    color = Color(211, 219, 222, 255), -- Team color
    model = "models/aussiwozzi/cgi/base/2ndac_trooper.mdl", -- Player model
    description = [[212th Attack Batallion]],  -- Job description
    weapons = {"rw_sw_dc15a_o","rw_sw_dc17ext","rw_sw_dp23","jet_mk5"}, -- Additional weapons
    command = "212thJET", -- Command to become the job
    max = 5, -- Maximum amount of said job
    salary = 350, -- Salary
    admin = 0, -- Requires Admin? 1 for yes, 0 for no.
    vote = false, -- Do they need to vote? true for yes, false for no.
    sortOrder = 4;
	PlayerSpawn = function(ply) ply:SetHealth(300) ply:SetMaxHealth(300) ply:SetArmor(300) ply:SetMaxArmor(300) end,
	hasLicense = true, -- Has a license
	category = "212th Attack",

})
TEAM_212TH = DarkRP.createJob("212th Medic", { -- Name
    color = Color(211, 219, 222, 255), -- Team color
    model = "models/aussiwozzi/cgi/base/212th_medic.mdl", -- Player model
    description = [[212th Attack Batallion]],  -- Job description
    weapons = {"rw_sw_dc15a_o","rw_sw_dc17ext","rw_sw_dc15s","weapon_bactainjector",'weapon_bactanade'}, -- Additional weapons
    command = "212thMED", -- Command to become the job
    max = 5, -- Maximum amount of said job
    salary = 350, -- Salary
    admin = 0, -- Requires Admin? 1 for yes, 0 for no.
    vote = false, -- Do they need to vote? true for yes, false for no.
    sortOrder = 4;
	PlayerSpawn = function(ply) ply:SetHealth(300) ply:SetMaxHealth(300) ply:SetArmor(300) ply:SetMaxArmor(300) end,
	hasLicense = true, -- Has a license
	category = "212th Attack",

})
-----91st Recon Corps
TEAM_91ST = DarkRP.createJob("91st Trooper", { -- Name
    color = Color(211, 219, 222, 255), -- Team color
    model = "models/aussiwozzi/cgi/base/91st_trooper.mdl", -- Player model
    description = [[91st Recon]],  -- Job description
    weapons = {"rw_sw_dc15x","rw_sw_dc17ext","rw_sw_dc15s","realistic_hook"}, -- Additional weapons
    command = "91stpvtT", -- Command to become the job
    max = 0, -- Maximum amount of said job
    salary = 350, -- Salary
    admin = 0, -- Requires Admin? 1 for yes, 0 for no.
    vote = false, -- Do they need to vote? true for yes, false for no.
    sortOrder = 5;
	PlayerSpawn = function(ply) ply:SetHealth(300) ply:SetMaxHealth(300) ply:SetArmor(300) ply:SetMaxArmor(300) end,
	hasLicense = false, -- Has a license
	category = "91st Recon",
	

})
TEAM_91ST = DarkRP.createJob("Commander Neyo", { -- Name
    color = Color(211, 219, 222, 255), -- Team color
    model = "models/aussiwozzi/cgi/base/91st_neyo.mdl", -- Player model
    description = [[91st Recon]],  -- Job description
    weapons = {"rw_sw_dc15x","rw_sw_dc17ext","rw_sw_dc15s","rw_sw_valken38x","weapon_bactainjector",'weapon_bactanade',"realistic_hook","weapon_ncs_defib"}, -- Additional weapons
    command = "91stpvtN", -- Command to become the job
    max = 1, -- Maximum amount of said job
    salary = 500, -- Salary
    admin = 0, -- Requires Admin? 1 for yes, 0 for no.
    vote = false, -- Do they need to vote? true for yes, false for no.
    sortOrder = 5;
	PlayerSpawn = function(ply) ply:SetHealth(500) ply:SetMaxHealth(500) ply:SetArmor(300) ply:SetMaxArmor(300) end,
	hasLicense = false, -- Has a license
	category = "91st Recon",
	

})
TEAM_91ST = DarkRP.createJob("91st Arf", { -- Name
    color = Color(211, 219, 222, 255), -- Team color
    model = "models/aussiwozzi/cgi/base/91st_arf.mdl", -- Player model
    description = [[91st Recon]],  -- Job description
    weapons = {"rw_sw_dc17ext","rw_sw_dc15s","rw_sw_dc15x","realistic_hook"}, -- Additional weapons
    command = "91stARF", -- Command to become the job
    max = 5, -- Maximum amount of said job
    salary = 350, -- Salary
    admin = 0, -- Requires Admin? 1 for yes, 0 for no.
    vote = false, -- Do they need to vote? true for yes, false for no.
    sortOrder = 5;
	PlayerSpawn = function(ply) ply:SetHealth(300) ply:SetMaxHealth(300) ply:SetArmor(300) ply:SetMaxArmor(300) end,
	hasLicense = false, -- Has a license
	category = "91st Recon",
	

})
TEAM_91ST = DarkRP.createJob("91st ARC", { -- Name
    color = Color(211, 219, 222, 255), -- Team color
    model = "models/aussiwozzi/cgi/base/91st_arc.mdl", -- Player model
    description = [[91st Recon]],  -- Job description
    weapons = {"rw_sw_dc17ext","rw_sw_dc15s","rw_sw_dc15x","realistic_hook"}, -- Additional weapons
    command = "91stBARC", -- Command to become the job
    max = 5, -- Maximum amount of said job
    salary = 350, -- Salary
    admin = 0, -- Requires Admin? 1 for yes, 0 for no.
    vote = false, -- Do they need to vote? true for yes, false for no.
    sortOrder = 5;
	PlayerSpawn = function(ply) ply:SetHealth(300) ply:SetMaxHealth(300) ply:SetArmor(300) ply:SetMaxArmor(300) end,
	hasLicense = false, -- Has a license
	category = "91st Recon",
 })       

-----Muunilinstr 10
TEAM_M10 = DarkRP.createJob("Muunilinst 10 Fordo", { -- Name
    color = Color(211, 219, 222, 255), -- Team color
    model = "models/aussiwozzi/cgi/base/arc_fordo.mdl", -- Player model
    description = [[Fordo Captain]],  -- Job description
    weapons = {"rw_sw_westarm5","rw_sw_dual_dc17s","weapon_bactainjector","climb_swep2","seal6-c4","realistic_hook","weapon_ncs_defib"}, -- Additional weapons
    command = "Fordo", -- Command to become the job
    max = 1, -- Maximum amount of said job
    salary = 700, -- Salary
    admin = 0, -- Requires Admin? 1 for yes, 0 for no.
    vote = false, -- Do they need to vote? true for yes, false for no.
    sortOrder = 9;
	PlayerSpawn = function(ply) ply:SetHealth(700) ply:SetMaxHealth(700) ply:SetArmor(300) ply:SetMaxArmor(300) end,
	hasLicense = false, -- Has a license
	category = "Muunilinst 10",              

})
TEAM_M10 = DarkRP.createJob("Muunilinst 10 Heavy", { -- Name
    color = Color(211, 219, 222, 255), -- Team color
    model = {"models/aussiwozzi/cgi/base/arc_lt_heavy.mdl","models/aussiwozzi/cgi/base/arc_cpt_heavy.mdl"}, -- Player model
    description = [[Muunilinst 10 Heavy]],  -- Job description
    weapons = {"rw_sw_westarm5","rw_sw_dual_dc17s","weapon_bactainjector","rw_sw_smartlauncher","climb_swep2","reciprocating_quad_blaster","seal6-c4","realistic_hook"}, ---
    command = "M10heavy", -- Command to become the job
    max = 1, -- Maximum amount of said job
    salary = 700, -- Salary
    admin = 0, -- Requires Admin? 1 for yes, 0 for no.
    vote = false, -- Do they need to vote? true for yes, false for no.
    sortOrder = 9;
	PlayerSpawn = function(ply) ply:SetHealth(700) ply:SetMaxHealth(700) ply:SetArmor(300) ply:SetMaxArmor(300) end,
	hasLicense = false, -- Has a license
	category = "Muunilinst 10",

    
})
TEAM_M10 = DarkRP.createJob("Muunilinst 10 Sniper", { -- Name
    color = Color(211, 219, 222, 255), -- Team color
    model = {"models/aussiwozzi/cgi/base/arc_lt_marksman.mdl","models/aussiwozzi/cgi/base/arc_cpt_marksman.mdl"}, -- Player model
    description = [[Muunilinst 10 Sniper]],  -- Job description
    weapons = {"rw_sw_westarm5","rw_sw_dual_dc17s","weapon_bactainjector","climb_swep2","seal6-c4","realistic_hook"}, -- Additional weapons
    command = "M10Sniper", -- Command to become the job
    max = 1, -- Maximum amount of said job
    salary = 700, -- Salary
    admin = 0, -- Requires Admin? 1 for yes, 0 for no.
    vote = false, -- Do they need to vote? true for yes, false for no.
    sortOrder = 9;	
    PlayerSpawn = function(ply) ply:SetHealth(700) ply:SetMaxHealth(700) ply:SetArmor(300) ply:SetMaxArmor(300) end,
	hasLicense = false, -- Has a license
	category = "Muunilinst 10",  
})
TEAM_M10 = DarkRP.createJob("Muunilinst 10 Medic", { -- Name
    color = Color(211, 219, 222, 255), -- Team color
    model = {"models/aussiwozzi/cgi/base/arc_lt_medic.mdl","models/aussiwozzi/cgi/base/arc_cpt_medic.mdl"},-- Player model
    description = [[Muunilinst 10 Medic]],  -- Job description
    weapons = {"rw_sw_westarm5","rw_sw_dual_dc17s","weapon_bactainjector","weapon_bactanade","climb_swep2","seal6-c4","realistic_hook","weapon_ncs_defib"}, -- Additional weapons
    command = "M10Medic", -- Command to become the job
    max = 1, -- Maximum amount of said job
    salary = 700, -- Salary
    admin = 0, -- Requires Admin? 1 for yes, 0 for no.
    vote = false, -- Do they need to vote? true for yes, false for no.
    sortOrder = 9;
	PlayerSpawn = function(ply) ply:SetHealth(700) ply:SetMaxHealth(700) ply:SetArmor(300) ply:SetMaxArmor(300) end,
    hasLicense = false, -- Has a license
    category = "Muunilinst 10",         
})
TEAM_M10 = DarkRP.createJob("Muunilinst 10 Pilot", { -- Name
    color = Color(211, 219, 222, 255), -- Team color
    model = {"models/aussiwozzi/cgi/base/arc_sgt_marksman.mdl"}, -- Player model
    description = [[Muunilinst 10 Pilot]],  -- Job description
    weapons = {"rw_sw_westarm5","rw_sw_dual_dc17s","weapon_bactainjector","climb_swep2","seal6-c4","realistic_hook"}, -- Additional weapons
    command = "M10Pilot", -- Command to become the job
    max = 1, -- Maximum amount of said job
    salary = 700, -- Salary
    admin = 0, -- Requires Admin? 1 for yes, 0 for no.
    vote = false, -- Do they need to vote? true for yes, false for no.
    sortOrder = 9;
	PlayerSpawn = function(ply) ply:SetHealth(700) ply:SetMaxHealth(700) ply:SetArmor(300) ply:SetMaxArmor(300) end,
	hasLicense = false, -- Has a license
	category = "Muunilinst 10",              

})
TEAM_M10 = DarkRP.createJob("Muunilinst 10 Engineer", { -- Name
    color = Color(211, 219, 222, 255), -- Team color
    model = {"models/aussiwozzi/cgi/base/arc_lt_grenadier.mdl"}, -- Player model
    description = [[Muunilinst 10 Engineer]],  -- Job description
    weapons = {"rw_sw_westarm5","rw_sw_dual_dc17s","weapon_bactainjector","climb_swep2","seal6-c4","alydus_fortificationbuildertablet","weapon_lvsrepair","realistic_hook"}, -- Additional weapons
    command = "M10ENG", -- Command to become the job
    max = 1, -- Maximum amount of said job
    salary = 700, -- Salary
    admin = 0, -- Requires Admin? 1 for yes, 0 for no.
    vote = false, -- Do they need to vote? true for yes, false for no.
    sortOrder = 9;
	PlayerSpawn = function(ply) ply:SetHealth(700) ply:SetMaxHealth(700) ply:SetArmor(300) ply:SetMaxArmor(300) end,
	hasLicense = false, -- Has a license
	category = "Muunilinst 10",                       
})    
TEAM_M10 = DarkRP.createJob("Muunilinst 10 Trooper", { -- Name
    color = Color(211, 219, 222, 255), -- Team color
    model = {"models/aussiwozzi/cgi/base/arc_lt.mdl","models/aussiwozzi/cgi/base/arc_cpt.mdl"}, -- Player model
    description = [[Muunilinst 10 trooper]],  -- Job description
    weapons = {"rw_sw_westarm5","rw_sw_dual_dc17s","weapon_bactainjector","climb_swep2","seal6-c4","realistic_hook"}, -- Additional weapons
    command = "M10TPR", -- Command to become the job
    max = 1, -- Maximum amount of said job
    salary = 700, -- Salary
    admin = 0, -- Requires Admin? 1 for yes, 0 for no.
    vote = false, -- Do they need to vote? true for yes, false for no.
    sortOrder = 9;
	PlayerSpawn = function(ply) ply:SetHealth(700) ply:SetMaxHealth(700) ply:SetArmor(300) ply:SetMaxArmor(300) end,
	hasLicense = false, -- Has a license
	category = "Muunilinst 10",              
})
TEAM_M10 = DarkRP.createJob("Muunilinst 10 Recruit", { -- Name
    color = Color(211, 219, 222, 255), -- Team color
    model = {"models/aussiwozzi/cgi/base/arc_sgt_grenadier.mdl",}, -- Player model
    description = [[Muunilinst 10 Recruit]],  -- Job description
    weapons = {"rw_sw_westarm5","rw_sw_dual_dc17s","weapon_bactainjector","climb_swep2","seal6-c4","realistic_hook"}, -- Additional weapons
    command = "M10RCT", -- Command to become the job
    max = 6, -- Maximum amount of said job
    salary = 300, -- Salary
    admin = 0, -- Requires Admin? 1 for yes, 0 for no.
    vote = false, -- Do they need to vote? true for yes, false for no.
    sortOrder = 9;
	PlayerSpawn = function(ply) ply:SetHealth(700) ply:SetMaxHealth(700) ply:SetArmor(300) ply:SetMaxArmor(300) end,
	hasLicense = false, -- Has a license
	category = "Muunilinst 10",              
})
----------Ground Crew
TEAM_GC = DarkRP.createJob("Ground Crew Engineer", { -- Name
    color = Color(211, 219, 222, 255), -- Team color
    model = {"models/jajoff/sps/republic/tc13j/rsb01.mdl","models/jajoff/sps/republic/tc13j/rsb01_female.mdl"}, -- Player model
    description = [[Ground Crew Engineer]],  -- Job description
    weapons = {"rw_sw_dc15s","rw_sw_dc17ext","alydus_fortificationbuildertablet","weapon_lvsrepair"}, -- Additional weapons
    command = "GCE", -- Command to become the job
    max = 0, -- Maximum amount of said job
    salary = 230, -- Salary
    admin = 0, -- Requires Admin? 1 for yes, 0 for no.
    vote = false, -- Do they need to vote? true for yes, false for no.
    sortOrder = 11;
	PlayerSpawn = function(ply) ply:SetHealth(300) ply:SetMaxHealth(300) ply:SetArmor(300) ply:SetMaxArmor(300) end,
	hasLicense = true, -- Has a license
	category = "Ground Crew",
})
TEAM_GC = DarkRP.createJob("Ground Crew Commander", { -- Name
    color = Color(211, 219, 222, 255), -- Team color
    model = {"models/jajoff/sps/republic/tc13j/navy_01.mdl","models/jajoff/sps/republic/tc13j/navy01_female.mdl"}, -- Player model
    description = [[Ground Crew Commander]],  -- Job description
    weapons = {"rw_sw_dc15a","rw_sw_dc15s","rw_sw_dc17ext","alydus_fortificationbuildertablet","weapon_lvsrepair"}, -- Additional weapons
    command = "GCC", -- Command to become the job
    max = 0, -- Maximum amount of said job
    salary = 400, -- Salary
    admin = 0, -- Requires Admin? 1 for yes, 0 for no.
    vote = false, -- Do they need to vote? true for yes, false for no.
    sortOrder = 11;
	PlayerSpawn = function(ply) ply:SetHealth(300) ply:SetMaxHealth(300) ply:SetArmor(300) ply:SetMaxArmor(300) end,
	hasLicense = true, -- Has a license
	category = "Ground Crew",
})
TEAM_GC = DarkRP.createJob("Ground Crew Officer", { -- Name
    color = Color(211, 219, 222, 255), -- Team color
    model = {"models/jajoff/sps/republic/tc13j/navy_02.mdl","models/jajoff/sps/republic/tc13j/navy02_female.mdl"}, -- Player model
    description = [[Ground Crew Officer]],  -- Job description
    weapons = {"rw_sw_dc15a","rw_sw_dc15s","rw_sw_dc17ext","alydus_fortificationbuildertablet","weapon_lvsrepair"}, -- Additional weapons
    command = "CGO", -- Command to become the job
    max = 0, -- Maximum amount of said job
    salary = 300, -- Salary
    admin = 0, -- Requires Admin? 1 for yes, 0 for no.
    vote = false, -- Do they need to vote? true for yes, false for no.
    sortOrder = 11;
	PlayerSpawn = function(ply) ply:SetHealth(300) ply:SetMaxHealth(300) ply:SetArmor(300) ply:SetMaxArmor(300) end,
	hasLicense = true, -- Has a license
	category = "Ground Crew",
})
TEAM_GC = DarkRP.createJob("Ground Crew NCO", { -- Name
    color = Color(211, 219, 222, 255), -- Team color
    model = {"models/jajoff/sps/republic/tc13j/navy_03.mdl","models/jajoff/sps/republic/tc13j/navy03_female.mdl"}, -- Player model
    description = [[Ground Crew NCO]],  -- Job description
    weapons = {"rw_sw_dc15a","rw_sw_dc15s","rw_sw_dc17ext","alydus_fortificationbuildertablet","weapon_lvsrepair"}, -- Additional weapons
    command = "CGN", -- Command to become the job
    max = 0, -- Maximum amount of said job
    salary = 250, -- Salary
    admin = 0, -- Requires Admin? 1 for yes, 0 for no.
    vote = false, -- Do they need to vote? true for yes, false for no.
    sortOrder = 11;
	PlayerSpawn = function(ply) ply:SetHealth(300) ply:SetMaxHealth(300) ply:SetArmor(300) ply:SetMaxArmor(300) end,
	hasLicense = true, -- Has a license
	category = "Ground Crew",
})
TEAM_GC = DarkRP.createJob("Ground Crew Medic", { -- Name
    color = Color(211, 219, 222, 255), -- Team color
    model = {"models/jajoff/sps/republic/tc13j/navy_medic.mdl","models/jajoff/sps/republic/tc13j/navy_medic_female.mdl"},-- Player model
    description = [[Ground Crew Medic]],  -- Job description
    weapons = {"rw_sw_dc15s","rw_sw_dc17ext","alydus_fortificationbuildertablet","weapon_lvsrepair"}, -- Additional weapons
    command = "CGM", -- Command to become the job
    max = 0, -- Maximum amount of said job
    salary = 230, -- Salary
    admin = 0, -- Requires Admin? 1 for yes, 0 for no.
    vote = false, -- Do they need to vote? true for yes, false for no.
    sortOrder = 11;
	PlayerSpawn = function(ply) ply:SetHealth(300) ply:SetMaxHealth(300) ply:SetArmor(300) ply:SetMaxArmor(300) end,
	hasLicense = true, -- Has a license
	category = "Ground Crew",
})
TEAM_GC = DarkRP.createJob("Ground Crew Enlisted", { -- Name
    color = Color(211, 219, 222, 255), -- Team color
    model = {"models/jajoff/sps/republic/tc13j/navy_04.mdl","models/jajoff/sps/republic/tc13j/navy04_female.mdl"}, -- Player model
    description = [[Ground Crew Enlisted]],  -- Job description
    weapons = {"rw_sw_dc15s","rw_sw_dc17ext","alydus_fortificationbuildertablet","weapon_lvsrepair"}, -- Additional weapons
    command = "CGT", -- Command to become the job
    max = 0, -- Maximum amount of said job
    salary = 200, -- Salary
    admin = 0, -- Requires Admin? 1 for yes, 0 for no.
    vote = false, -- Do they need to vote? true for yes, false for no.
    sortOrder = 11;
	PlayerSpawn = function(ply) ply:SetHealth(300) ply:SetMaxHealth(300) ply:SetArmor(300) ply:SetMaxArmor(300) end,
	hasLicense = true, -- Has a license
	category = "Ground Crew",
})
-----Bad Batch
TEAM_91ST = DarkRP.createJob("Bad Batch Hunter", { -- Name
    color = Color(211, 219, 222, 255), -- Team color
    model = "models/aussiwozzi/cgi/base/91st_trooper.mdl", -- Player model
    description = [[CF 99]],  -- Job description
    weapons = {"rw_sw_dc15x","rw_sw_dc17ext","rw_sw_dc15s","realistic_hook"}, -- Additional weapons
    command = "bbh", -- Command to become the job
    max = 1, -- Maximum amount of said job
    salary = 350, -- Salary
    admin = 0, -- Requires Admin? 1 for yes, 0 for no.
    vote = false, -- Do they need to vote? true for yes, false for no.
    sortOrder = 8;
	PlayerSpawn = function(ply) ply:SetHealth(300) ply:SetMaxHealth(300) ply:SetArmor(300) ply:SetMaxArmor(300) end,
	hasLicense = false, -- Has a license
	category = "Bad Batch",
	

})
TEAM_91ST = DarkRP.createJob("Bad Batch Wrecker", { -- Name
    color = Color(211, 219, 222, 255), -- Team color
    model = "models/aussiwozzi/cgi/base/91st_neyo.mdl", -- Player model
    description = [[CF 99]],  -- Job description
    weapons = {"rw_sw_dc15x","rw_sw_dc17ext","rw_sw_dc15s","rw_sw_valken38x","weapon_bactainjector",'weapon_bactanade',"realistic_hook","weapon_ncs_defib"}, -- Additional weapons
    command = "bbw", -- Command to become the job
    max = 1, -- Maximum amount of said job
    salary = 500, -- Salary
    admin = 0, -- Requires Admin? 1 for yes, 0 for no.
    vote = false, -- Do they need to vote? true for yes, false for no.
    sortOrder = 8;
	PlayerSpawn = function(ply) ply:SetHealth(500) ply:SetMaxHealth(500) ply:SetArmor(300) ply:SetMaxArmor(300) end,
	hasLicense = false, -- Has a license
	category = "Bad Batch",
	

})
TEAM_91ST = DarkRP.createJob("Bad Batch Tech", { -- Name
    color = Color(211, 219, 222, 255), -- Team color
    model = "models/aussiwozzi/cgi/base/91st_arf.mdl", -- Player model
    description = [[CF 99]],  -- Job description
    weapons = {"rw_sw_dc17ext","rw_sw_dc15s","rw_sw_dc15x","realistic_hook"}, -- Additional weapons
    command = "bbt", -- Command to become the job
    max = 1, -- Maximum amount of said job
    salary = 350, -- Salary
    admin = 0, -- Requires Admin? 1 for yes, 0 for no.
    vote = false, -- Do they need to vote? true for yes, false for no.
    sortOrder = 8;
	PlayerSpawn = function(ply) ply:SetHealth(300) ply:SetMaxHealth(300) ply:SetArmor(300) ply:SetMaxArmor(300) end,
	hasLicense = false, -- Has a license
	category = "Bad Batch",
	

})
TEAM_91ST = DarkRP.createJob("Bad Batch Echo", { -- Name
    color = Color(211, 219, 222, 255), -- Team color
    model = "models/aussiwozzi/cgi/base/91st_arc.mdl", -- Player model
    description = [[CF 99]],  -- Job description
    weapons = {"rw_sw_dc17ext","rw_sw_dc15s","rw_sw_dc15x","realistic_hook"}, -- Additional weapons
    command = "bbe", -- Command to become the job
    max = 1, -- Maximum amount of said job
    salary = 350, -- Salary
    admin = 0, -- Requires Admin? 1 for yes, 0 for no.
    vote = false, -- Do they need to vote? true for yes, false for no.
    sortOrder = 8;
	PlayerSpawn = function(ply) ply:SetHealth(300) ply:SetMaxHealth(300) ply:SetArmor(300) ply:SetMaxArmor(300) end,
	hasLicense = false, -- Has a license
	category = "Bad Batch",
 })
TEAM_91ST = DarkRP.createJob("Bad Batch Crosshair", { -- Name
    color = Color(211, 219, 222, 255), -- Team color
    model = "models/aussiwozzi/cgi/base/91st_arc.mdl", -- Player model
    description = [[CF 99]],  -- Job description
    weapons = {"rw_sw_dc17ext","rw_sw_dc15s","rw_sw_dc15x","realistic_hook"}, -- Additional weapons
    command = "bbcro", -- Command to become the job
    max = 1, -- Maximum amount of said job
    salary = 350, -- Salary
    admin = 0, -- Requires Admin? 1 for yes, 0 for no.
    vote = false, -- Do they need to vote? true for yes, false for no.
    sortOrder = 8;
	PlayerSpawn = function(ply) ply:SetHealth(300) ply:SetMaxHealth(300) ply:SetArmor(300) ply:SetMaxArmor(300) end,
	hasLicense = false, -- Has a license
	category = "Bad Batch",
 })       
    



--[[---------------------------------------------------------------------------
Define which team joining players spawn into and what team you change to if demoted
---------------------------------------------------------------------------]]
GAMEMODE.DefaultTeam = TEAM_CR
--[[---------------------------------------------------------------------------
Define which teams belong to civil protection
Civil protection can set warrants, make people wanted and do some other police related things
---------------------------------------------------------------------------]]
GAMEMODE.CivilProtection = {
    [TEAM_POLICE] = false,
    [TEAM_CHIEF] = false,
    [TEAM_MAYOR] = false,
}
--[[---------------------------------------------------------------------------
Jobs that are hitmen (enables the hitman menu)
---------------------------------------------------------------------------]]
DarkRP.addHitmanTeam(TEAM_MOB)