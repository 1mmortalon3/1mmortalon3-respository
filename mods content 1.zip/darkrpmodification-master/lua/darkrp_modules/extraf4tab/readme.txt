--[[---------------------------------------------------------------------------
---------------------------------------------------------------------------
F4 Mod example
---------------------------------------------------------------------------
---------------------------------------------------------------------------]]

This is an example module that adds an extra tab and shows some more F4 menu things you can do

This is to make F4 editing easier for you. It also shows that it can be done without having to modify the existing F4 menu.
