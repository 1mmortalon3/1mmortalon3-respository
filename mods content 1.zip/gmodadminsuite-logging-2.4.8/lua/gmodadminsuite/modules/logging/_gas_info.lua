return {
	DefaultEnabled = true,
	Name = "Billy's Logs",
	Category = GAS.MODULE_CATEGORY_ADMINISTRATION,
	Wiki = "https://gmodsto.re/blogs-wiki",
	Icon = "icon16/database_lightning.png",
	GmodStore = "6016",
	License = '{"licensee":"76561198256405950","keys":{"xeon-de":"LXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX","xeon-us":"LXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"}}'
}