-- Sets up screen width and height configuration.
LDT_Closetter.Config.Scrw, LDT_Closetter.Config.Scrh = ScrW(), ScrH()
local fullTransparentColor = Color(255, 255, 255, 0)

-- Calculates and returns size values relative to a 1080p monitor.
function LDT_Closetter.GetHeight(num)
    return (LDT_Closetter.Config.Scrh*(num / 1080))
end

-- Calculates and returns size values relative to a 1920 width monitor.
function LDT_Closetter.GetWidth(num)
    return (LDT_Closetter.Config.Scrw*(num / 1920))
end

-- Returns the interpolation value between two points.
function LDT_Closetter.InverseLerp(pos, p1, p2)
    if p1 == p2 then 
        return 1 
    end
    return (pos - p1) / (p2 - p1)
end

-- Draws a top-rounded gradient box with specified parameters.
function LDT_Closetter.DrawTopRoundedGradientBox(cornerRadius, x, y, width, height, color1, color2, horizontal)
    draw.RoundedBoxEx(cornerRadius, x, y, width, height / 2, color1, true, true, false, false)

    surface.SetDrawColor(color1)
    surface.DrawRect(x, y + height / 2, width, height / 2)

    local gradientTexture = surface.GetTextureID("gui/gradient")
    surface.SetTexture(gradientTexture)

    for i = 0, (horizontal and width or height) do
        local alpha = (i / (horizontal and width or height)) * 255
        surface.SetDrawColor(Color(color2.r, color2.g, color2.b, alpha))
        
        if horizontal then
            surface.DrawTexturedRect(x + i, y, 1, height)
        else
            surface.DrawTexturedRect(x, y + i, width, 1)
        end
    end

    draw.RoundedBoxEx(cornerRadius, x, y, width, height / 2, fullTransparentColor, true, true, false, false)
end

-- Retrieves a local preset based on the preset ID.
function LDT_Closetter.GetLocalPreset(presetID)
    for k,v in ipairs(LDT_Closetter.Presets) do
        if v.PresetID == presetID then
            return v
        end
    end
end

-- Creates fonts with correct sizes based on screen dimensions.
local fontSize = {24, 26, 30, 36}
local fontSizeBold = {30, 36, 40, 50}
local function CreateFonts()
	for k,v in ipairs(fontSize) do 
		surface.CreateFont("WorkSans"..v, {font = "Work Sans Regular",    size = LDT_Closetter.GetWidth(v),     weight = 500,	antialias = true})
	end
	
    for k,v in ipairs(fontSizeBold) do 
		surface.CreateFont("WorkSans"..v.."-Bold", {font = "Work Sans Bold",    size = LDT_Closetter.GetWidth(v),     weight = 500})
	end
end
CreateFonts()

-- Creates fonts for 3D2D text with correct sizes.
local fontSizeBold3D2D = {30, 40, 150}
local fontSize3D2D = {80}
local function Create3D2DFonts()
    for k,v in ipairs(fontSizeBold3D2D) do 
		surface.CreateFont("WorkSans3D2D"..v.."-Bold", {font = "Work Sans Bold",    size = v,     weight = 500})
	end

	for k,v in ipairs(fontSize3D2D) do 
		surface.CreateFont("WorkSans3D2D"..v, {font = "Work Sans",    size = v,     weight = 500})
	end
end
Create3D2DFonts()

-- Adjusts screen width and height configuration and recreates fonts on screen size changes.
hook.Add( "OnScreenSizeChanged", "LDT_Closetter.OnScreenSizeChanged_ChnageFont", function()
    LDT_Closetter.Config.Scrw, LDT_Closetter.Config.Scrh = ScrW(), ScrH()
    CreateFonts()
end)