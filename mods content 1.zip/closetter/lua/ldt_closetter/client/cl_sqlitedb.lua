-- Initializes the presets table.
LDT_Closetter.Presets = {}

-- Creates necessary database tables for LDT_Closetter.
function LDT_Closetter.CreateDBTables()
    print("[LDT_CLOSETTER] Creating LDT_Closetter tables")
    sql.Query([[
        CREATE TABLE IF NOT EXISTS LDT_Closetter_Presets (
            ID INTEGER PRIMARY KEY, 
            JobName TEXT NOT NULL, 
            PresetName TEXT NOT NULL, 
            ModelName TEXT NOT NULL,
            SkinID INT NOT NULL,
            Bodygroups JSON NOT NULL
        );]])
end

-- Loads saved presets from the database into the LDT_Closetter.Presets table.
function LDT_Closetter.GetSavedPresets()
    local data = sql.Query("SELECT * FROM LDT_Closetter_Presets")
    if data == false then return end

    LDT_Closetter.Presets = {}
    if data then
        for k, v in pairs(data) do
            table.insert(LDT_Closetter.Presets, {
                PresetID = tonumber(v.ID),
                JobName = v.JobName,
                PresetName = v.PresetName,
                ModelName = v.ModelName,
                SkinID = v.SkinID,
                Bodygroups = util.JSONToTable(v.Bodygroups)
            })
        end
    end
end

-- Saves a new preset to the database.
function LDT_Closetter.SaveNewPreset(jobName, presetName, modelName, skinID, bodygroups, callback)
    sql.Query("INSERT INTO LDT_Closetter_Presets (JobName, PresetName, ModelName, SkinID, Bodygroups) VALUES ('" .. jobName .. "', '" .. presetName .. "', '" .. modelName .. "', " .. skinID .. ", '" .. util.TableToJSON(bodygroups) .. "')")

    LDT_Closetter.GetSavedPresets()

    if callback then
        callback()
    end
end

-- Removes a preset from the database.
function LDT_Closetter.RemovePreset(presetID, callback)
    sql.Query("DELETE FROM LDT_Closetter_Presets WHERE ID = " .. presetID)

    LDT_Closetter.GetSavedPresets()

    if callback then
        callback()
    end
end