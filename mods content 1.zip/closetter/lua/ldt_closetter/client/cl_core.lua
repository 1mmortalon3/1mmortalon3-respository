-- Function to open the closet UI with specified parameters.
function LDT_Closetter.OpenClosetUI(closetID, globalPresets, ply)
    if IsValid(LDT_Closetter.closetMainPanel) then
        LDT_Closetter.closetMainPanel:Remove()
    end

    LDT_Closetter.closetMainPanel = vgui.Create( "LDT_Closetter_Frame" )
    LDT_Closetter.closetMainPanel:Center()
    LDT_Closetter.closetMainPanel:MakePopup()
    LDT_Closetter.closetMainPanel:Show()
    LDT_Closetter.closetMainPanel:SetData(closetID, globalPresets, ply)
end

-- Loads a preset for a player from the local presets.
function LDT_Closetter.LoadPreset(presetID, closetID, targetPly)
    local preset = LDT_Closetter.GetLocalPreset(presetID)
    if not preset then return end

    net.Start("LDT_Closetter.LoadUserPreset")
        net.WriteEntity(targetPly)
        net.WriteInt(closetID, 9)
        net.WriteString(preset.ModelName)
        net.WriteUInt(preset.SkinID, 6)
        net.WriteUInt(#preset.Bodygroups, 8)
        for k, v in pairs(preset.Bodygroups) do
            net.WriteUInt(k, 6)
            net.WriteUInt(v, 6)
        end
    net.SendToServer()
end

-- Network receive function to handle opening the closet UI.
net.Receive("LDT_Closetter.OpenClosetUI", function()
    local closetID = net.ReadInt(9)
    local ply = net.ReadEntity()
    local numberOfGlobalPresets = net.ReadUInt(8)
    local globalPresets = {}
    for i = 1, numberOfGlobalPresets do
        table.insert(globalPresets, {
            PresetID = net.ReadUInt(22),
            PresetName = net.ReadString()
        })
    end

    LDT_Closetter.OpenClosetUI(closetID, globalPresets, ply)
end)

-- Network receive function to handle model change.
net.Receive("LDT_Closetter.ModelChanged", function()
    local model = net.ReadString()

    if IsValid(LDT_Closetter.closetMainPanel) then
        LDT_Closetter.closetMainPanel.center.model:SetModel(model)
        LDT_Closetter.closetMainPanel:RightPanel()
    end
end)

-- Network receive function to handle new global preset saved.
net.Receive("LDT_Closetter.NewGlobalPresetSaved", function()
    local presetID = net.ReadUInt(22)
    local presetName = net.ReadString()

    if IsValid(LDT_Closetter.closetMainPanel) then
        LDT_Closetter.closetMainPanel:AddNewGlobalPreset(presetName, presetID)
    end
end)

-- Network receive function to handle removing a global preset.
net.Receive("LDT_Closetter.RemoveGlobalPresetCallback", function()
    local presetID = net.ReadUInt(22)

    if IsValid(LDT_Closetter.closetMainPanel) then
        LDT_Closetter.closetMainPanel:RemoveGlobalPreset(presetID)
    end
end)

-- Network receive function to handle getting job users callback.
net.Receive("LDT_Closetter.GetJobUsersCallback", function()
    local users = {}
    local numberOfUsers = net.ReadUInt(8)
    for i = 1, numberOfUsers do
        table.insert(users, net.ReadString())
    end

    if IsValid(LDT_Closetter.closetMainPanel) then
        LDT_Closetter.closetMainPanel.right.cloneFromUsersPopUp:SetData(users)
        LDT_Closetter.closetMainPanel.right.cloneFromUsersPopUp:Show()
    end
end)

-- Network receive function to handle opening the admin menu.
net.Receive("LDT_Closetter.OpenAdminMenu", function()
    if IsValid(LDT_Closetter.adminMenu) then
        LDT_Closetter.adminMenu:Remove()
    end

    LDT_Closetter.adminMenu = vgui.Create( "LDT_Closetter_Admin_Frame" )
    LDT_Closetter.adminMenu:Center()
    LDT_Closetter.adminMenu:MakePopup()
    LDT_Closetter.adminMenu:Show()
end)

-- Checks if the player is loaded in and initializes necessary actions.
function LDT_Closetter.IsPlayerLoadedIn()
	if IsValid( LocalPlayer() ) then
		LDT_Closetter.ply = LocalPlayer()
        LDT_Closetter:CreateDBTables()
        LDT_Closetter:GetSavedPresets()

		hook.Remove( "HUDPaint", "LDT_Closetter.IsPlayerLoadedIn" )
	end
end
hook.Add( "HUDPaint", "LDT_Closetter.IsPlayerLoadedIn", LDT_Closetter.IsPlayerLoadedIn )

-- Removes a ghost enity if the player is not using the decal tool
hook.Add("Think", "LDT_Closetter.ThinkRemoveEnt", function()
	if not IsValid(LDT_Closetter.ply) then return end
	if not LDT_Closetter.ply:IsPlayer() then return end

	local tool = LDT_Closetter.ply:GetTool()
	if tool == nil then return end

	if tool.Mode != "ldt_closetter_closet_spawner" then
		if IsValid(LDT_Closetter.BodygrouprClosetEnt) then 
			LDT_Closetter.BodygrouprClosetEnt:Remove()
		end
	end
end)

-- Adds the bodyGroupr menu to the context menu.
list.Set( "DesktopWindows", "LDT_Closetter_GrouprMenu", {
        icon = "icon16/user_green.png",
        title = "bodyGroupr",
        width = 100,
        height = 100,
        onewindow = true,
        init = function( icon, window )
            window:Close()
            net.Start("LDT_Closetter.CanOpenClosetFromAnwhere")
            net.SendToServer()
        end
    }
)