local PANEL = {}

local xicon = Material("ldt_closetter/x.png", "noclamp smooth")
local gradientDown = Material("gui/gradient_down", "noclamp smooth")

-- Setup default properties of this panel
function PANEL:Init()
    self:Dock(RIGHT)
    self:DockMargin(LDT_Closetter.GetWidth(5), LDT_Closetter.GetHeight(5), LDT_Closetter.GetWidth(5), LDT_Closetter.GetHeight(5))
    self:SetWide(LDT_Closetter.GetWidth(400))

    self.parent = self:GetParent()
    self:Body()
end

function PANEL:Body()
    self.scroll = self:Add("DScrollPanel")
    self.scroll:Dock(FILL)
    self.scroll:DockMargin(0, 0, 0, LDT_Closetter.GetHeight(10))
    self.scroll.Paint = function(me, w, h)
    end
    local sbar = self.scroll:GetVBar()
    function sbar:Paint(w, h)
    end
    function sbar.btnUp:Paint(w, h)
    end
    function sbar.btnDown:Paint(w, h)
    end
    function sbar.btnGrip:Paint(w, h)
        draw.RoundedBox(8, w*0.5, 0, w * .4, h, LDT_Closetter.Config.Blue)
    end


    self.parent.job = self.parent.ply:getJobTable()
    self.parent.bodygroups = self.parent.ply:GetBodyGroups()
    self.parent.currentBodygroups = {}
    self.parent.skins = {}

    for i = 0, self.parent.center.model.Entity:SkinCount() - 1 do
        self.parent.skins[i] = i
    end

    self.parent.currentSkin = self.parent.ply:GetSkin()
    if self.parent.skins[self.parent.currentSkin] != nil then
        self.parent.center.model.Entity:SetSkin(self.parent.currentSkin)
    end
    
    for _, bodygroup in ipairs(self.parent.bodygroups) do
        local groupID = bodygroup.id
        local currentBodygroupValue = self.parent.ply:GetBodygroup(groupID)
        
        self.parent.currentBodygroups[groupID] = currentBodygroupValue
        self.parent.center.model.Entity:SetBodygroup(groupID, currentBodygroupValue)
    end

    local playermodels = self.parent.job.model

    if isstring(playermodels) then
        playermodels = {playermodels}
    end

    if playermodels then
        self.playermodelsTitle = self.scroll:Add("DPanel")
        self.playermodelsTitle:Dock(TOP)
        self.playermodelsTitle:SetTall(LDT_Closetter.GetHeight(40))
        self.playermodelsTitle.Paint = function(me, w, h)
            LDT_Closetter.DrawTopRoundedGradientBox(8, 0, 0, w, h*0.9, LDT_Closetter.Config.Grey, LDT_Closetter.Config.GreySecond, false)
            draw.RoundedBox(8, 0, h*0.9, w, h*0.1, LDT_Closetter.Config.Blue)
            draw.SimpleText(LDT_Closetter.GetLanguage("PlayersmodelsText"), "WorkSans30-Bold", w * 0.02, h * 0.475, LDT_Closetter.Config.White, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        end
    
        self.playermodels = self.scroll:Add("DIconLayout")
        self.playermodels:Dock(TOP)
        self.playermodels:DockMargin(0, LDT_Closetter.GetHeight(5), 0, LDT_Closetter.GetHeight(25))
        self.playermodels:SetSpaceX(LDT_Closetter.GetWidth(5))
        self.playermodels:SetSpaceY(LDT_Closetter.GetHeight(5))
    
        local parentWidth = LDT_Closetter.GetWidth(400)
        self.playermodelsBtns = {}
        for k, v in pairs(playermodels) do
            local playermodelName = v:match(".+/(.+).mdl")
            self.playermodelsBtns[k] = self.playermodels:Add("DButton")
            self.playermodelsBtns[k]:SetSize(((parentWidth-LDT_Closetter.GetWidth(20))/2), LDT_Closetter.GetHeight(28))
            self.playermodelsBtns[k]:SetText("")
            self.playermodelsBtns[k].hovered = false
            self.playermodelsBtns[k].Paint = function(me, w, h)
                local color = LDT_Closetter.Config.Blue
                if me.hovered then
                    color = LDT_Closetter.Config.BlueSecond
                end
                draw.RoundedBox(8, 0, 0, w, h, color)
                
                surface.SetFont("WorkSans26")
                local textWidth = surface.GetTextSize(playermodelName)
                local maxWidth = w * 0.9
    
                if textWidth > maxWidth then
                    while textWidth > maxWidth do
                        playermodelName = string.sub(playermodelName, 1, -2)
                        textWidth = surface.GetTextSize(playermodelName .. "...")
                    end
                    playermodelName = playermodelName .. "..."
                end
    
                draw.SimpleText(playermodelName, "WorkSans26", w * 0.5, h * 0.5, LDT_Closetter.Config.White, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            end
            self.playermodelsBtns[k].OnCursorEntered = function(me)
                me.hovered = true
            end
            self.playermodelsBtns[k].OnCursorExited = function(me)
                me.hovered = false
            end
            self.playermodelsBtns[k].DoClick = function()
                self.parent:SetNewModel(v)
            end
        end
    end

    self.playermodelsTitle = self.scroll:Add("DPanel")
    self.playermodelsTitle:Dock(TOP)
    self.playermodelsTitle:SetTall(LDT_Closetter.GetHeight(40))
    self.playermodelsTitle.Paint = function(me, w, h)
        LDT_Closetter.DrawTopRoundedGradientBox(8, 0, 0, w, h*0.9, LDT_Closetter.Config.Grey, LDT_Closetter.Config.GreySecond, false)
        draw.RoundedBox(8, 0, h*0.9, w, h*0.1, LDT_Closetter.Config.Blue)
        draw.SimpleText(LDT_Closetter.GetLanguage("SkinsText"), "WorkSans30-Bold", w * 0.02, h * 0.475, LDT_Closetter.Config.White, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
    end

    local availableSkins = nil
    if self.parent.job.skins and not LDT_Closetter.Config.AdminRanks[LDT_Closetter.GetPlayerGroup(LDT_Closetter.ply)] then 
        availableSkins = self.parent.job.skins
    end
    self.skinBtns = self.scroll:Add("LDT_Closetter_Btn_Panel")
    self.skinBtns:SetData(self.parent.skins, function(id)
        self.parent:SetNewSkin(id)
    end, availableSkins)

    self.bodygroupBtns = {}
    for k, v in ipairs(self.parent.bodygroups) do
        local bodyGroupName = v.name
        local availableBodygroups = nil
        if self.parent.job.bodygroups and not LDT_Closetter.Config.AdminRanks[LDT_Closetter.GetPlayerGroup(LDT_Closetter.ply)] then 
            availableBodygroups = self.parent.job.bodygroups[bodyGroupName]
        end

        self.bodygroupBtns[k] = self.scroll:Add("DPanel")
        self.bodygroupBtns[k]:Dock(TOP)
        self.bodygroupBtns[k]:SetTall(LDT_Closetter.GetHeight(40))
        self.bodygroupBtns[k].Paint = function(me, w, h)
            LDT_Closetter.DrawTopRoundedGradientBox(8,0, 0, w, h*0.9, LDT_Closetter.Config.Grey, LDT_Closetter.Config.GreySecond, false)
            draw.RoundedBox(8, 0, h*0.9, w, h*0.1, LDT_Closetter.Config.Blue)
            draw.SimpleText(v.name, "WorkSans30-Bold", w * 0.02, h * 0.475, LDT_Closetter.Config.White, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        end

        self.bodygroupBtns[k] = self.scroll:Add("LDT_Closetter_Btn_Panel")
        self.bodygroupBtns[k]:SetData(v.submodels, function(id)
            self.parent.center.model.Entity:SetBodygroup(v.id, id)
            self.parent:SetNewBodygroup(v.id, id)
        end, availableBodygroups)
    end

    if not LDT_Closetter.Config.EnableCloning then return end
    self.cloneFromUser = self:Add("DButton")
    self.cloneFromUser:Dock(BOTTOM)
    self.cloneFromUser:DockMargin(0, LDT_Closetter.GetHeight(5), 0, 0)
    self.cloneFromUser:SetTall(LDT_Closetter.GetHeight(35))
    self.cloneFromUser:SetText("")
    self.cloneFromUser.hovered = false
    self.cloneFromUser.Paint = function(me, w, h)
        local color = LDT_Closetter.Config.Blue
        if me.hovered then
            color = LDT_Closetter.Config.BlueSecond
        end
        draw.RoundedBox(8, 0, 0, w, h, color)
        draw.SimpleText(LDT_Closetter.GetLanguage("CloneFromUsersBtnText"), "WorkSans26", w * 0.5, h * 0.5, LDT_Closetter.Config.White, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    self.cloneFromUser.OnCursorEntered = function(me)
        me.hovered = true
    end
    self.cloneFromUser.OnCursorExited = function(me)
        me.hovered = false
    end
    self.cloneFromUser.DoClick = function()
        self.cloneFromUsersPopUp = vgui.Create("LDT_Closetter_Clone_From_Users")
        self.cloneFromUsersPopUp:Center()
        self.cloneFromUsersPopUp:MakePopup()
        net.Start("LDT_Closetter.GetJobUsers")
        net.SendToServer()
    end
end

-- Change the defualt paint.
function PANEL:Paint(w, h)
end

vgui.Register("LDT_Closetter_Right_Panel", PANEL, "DPanel")