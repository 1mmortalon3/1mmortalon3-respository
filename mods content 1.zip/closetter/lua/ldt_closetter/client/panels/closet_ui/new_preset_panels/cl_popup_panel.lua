local PANEL = {}

-- Setup default properties of this panel
function PANEL:Init()
    self:SetDraggable(false)
    self:SetTitle("")
    self:DockPadding(0, 0, 0, 0)
    self:ShowCloseButton(false)
    self:SetSize( LDT_Closetter.GetWidth(500), LDT_Closetter.GetHeight(210) )
    self.startTime = SysTime()
end

function PANEL:SetCallback(callback)
    self.callback = callback

    self:TopBar()
    self:Body()
end

function PANEL:TopBar() 
    self.topbar = self:Add("DPanel")
    self.topbar:Dock(TOP)
    self.topbar:SetTall(LDT_Closetter.GetHeight(50))
    self.topbar.Paint = function(me,w,h)
        draw.RoundedBoxEx(8, 0, 0, w, h, LDT_Closetter.Config.Blue, true, true, false, false)
        draw.SimpleText(LDT_Closetter.GetLanguage("NewPresetTitle"), "WorkSans36-Bold", w * 0 + LDT_Closetter.GetWidth(10), h * .5, LDT_Closetter.Config.White, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
    end
end

function PANEL:Body()
    self.body = self:Add("DPanel")
    self.body:Dock(FILL)
    self.body:DockMargin(LDT_Closetter.GetWidth(10), LDT_Closetter.GetHeight(10), LDT_Closetter.GetWidth(10), LDT_Closetter.GetHeight(10))
    self.body.Paint = function(me,w,h)
    end

    self.presetInputHolder = self.body:Add("DPanel")
    self.presetInputHolder:Dock(TOP)
    self.presetInputHolder:SetTall( LDT_Closetter.GetHeight(35) )
    self.presetInputHolder:DockMargin( 0, LDT_Closetter.GetHeight(10), 0, 0 )
    self.presetInputHolder.Paint = function(me, w, h)
        draw.RoundedBox( 8, 0, 0, w, h, LDT_Closetter.Config.GreySecond )
    end

    self.presetInput = self.presetInputHolder:Add("DTextEntry")
	self.presetInput:Dock( FILL )
	self.presetInput:DockMargin( LDT_Closetter.GetWidth(10), LDT_Closetter.GetHeight(5), LDT_Closetter.GetWidth(10), LDT_Closetter.GetHeight(5) )
	self.presetInput:SetPlaceholderText( "Name of the preset" )
    self.presetInput:SetPaintBackground( false )
    self.presetInput:SetFont( "WorkSans24" )
    self.presetInput:SetTextColor(LDT_Closetter.Config.White)
	self.presetInput.OnTextChanged = function(self)
        local text = self:GetText()
        if #text > 20 then
            self:SetText(text:sub(1, 20))
            self:SetCaretPos(20)
        end
    end
    
    self.closeBtn = self.body:Add("DButton")
    self.closeBtn:Dock(BOTTOM)
    self.closeBtn:DockMargin(0, LDT_Closetter.GetHeight(5), 0, 0)
    self.closeBtn:SetTall(LDT_Closetter.GetHeight(35))
    self.closeBtn:SetText("")
    self.closeBtn.hovered = false
    self.closeBtn.Paint = function(me,w,h)
        local color = LDT_Closetter.Config.Red
        if me.hovered then
            color = LDT_Closetter.Config.RedHover
        end
        draw.RoundedBox(8, 0, 0, w, h, color)
        draw.SimpleText(LDT_Closetter.GetLanguage("CloseBtnText"), "WorkSans26", w * 0.5, h * 0.5, LDT_Closetter.Config.White, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    self.closeBtn.OnCursorEntered = function(me)
        me.hovered = true
    end
    self.closeBtn.OnCursorExited = function(me)
        me.hovered = false
    end
    self.closeBtn.DoClick = function()
        LDT_Closetter.closetMainPanel:SetMouseInputEnabled(true)
        self:Close()
    end

    self.saveBtn = self.body:Add("DButton")
    self.saveBtn:Dock(BOTTOM)
    self.saveBtn:SetTall(LDT_Closetter.GetHeight(35))
    self.saveBtn:SetText("")
    self.saveBtn.Paint = function(me,w,h)
        local color = LDT_Closetter.Config.Blue
        if me.hovered then
            color = LDT_Closetter.Config.BlueSecond
        end
        draw.RoundedBox(8, 0, 0, w, h, color)
        draw.SimpleText(LDT_Closetter.GetLanguage("SaveBtnText"), "WorkSans26", w * 0.5, h * 0.5, LDT_Closetter.Config.White, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    self.saveBtn.OnCursorEntered = function(me)
        me.hovered = true
    end
    self.saveBtn.OnCursorExited = function(me)
        me.hovered = false
    end
    self.saveBtn.DoClick = function()
        if self.presetInput:GetValue() == "" then return end
        self.callback(self.presetInput:GetValue())
        LDT_Closetter.closetMainPanel:SetMouseInputEnabled(true)
        self:Close()
    end
end

-- Change the defualt paint.
function PANEL:Paint(w, h)
    Derma_DrawBackgroundBlur(self, self.startTime)
    draw.RoundedBox( 8, 0, 0, w, h, LDT_Closetter.Config.Grey )
end

vgui.Register("LDT_Closetter_Popup_New_Preset", PANEL, "DFrame")