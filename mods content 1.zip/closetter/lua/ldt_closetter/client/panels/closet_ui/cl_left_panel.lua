local PANEL = {}

local xicon = Material("ldt_closetter/x.png", "noclamp smooth")
local gradientDown = Material("gui/gradient_down", "noclamp smooth")

-- Setup default properties of this panel
function PANEL:Init()
    self:Dock(LEFT)
    self:DockMargin(LDT_Closetter.GetWidth(5), LDT_Closetter.GetHeight(5), LDT_Closetter.GetWidth(5), LDT_Closetter.GetHeight(5))
    self:SetWide(LDT_Closetter.GetWidth(400))

    self.parent = self:GetParent()
    self:Body()
end

function PANEL:GlobalPresets()
    self.globalPresetsTitle = self:Add("DPanel")
    self.globalPresetsTitle:Dock(TOP)
    self.globalPresetsTitle:SetTall(LDT_Closetter.GetHeight(40))
    self.globalPresetsTitle.Paint = function(me, w, h)
        LDT_Closetter.DrawTopRoundedGradientBox(8, 0, 0, w, h*0.9, LDT_Closetter.Config.Grey, LDT_Closetter.Config.GreySecond, false)
        draw.RoundedBox(8, 0, h*0.9, w, h*0.1, LDT_Closetter.Config.Blue)
        draw.SimpleText(LDT_Closetter.GetLanguage("ServerJobPresetsText"), "WorkSans30-Bold", w * 0.02, h * 0.475, LDT_Closetter.Config.White, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
    end

    self.scrollGlobal = self:Add("DScrollPanel")
    self.scrollGlobal:Dock(TOP)
    self.scrollGlobal:SetTall(LDT_Closetter.GetHeight(335))
    self.scrollGlobal:DockMargin(0, 0, 0, LDT_Closetter.GetHeight(10))
    self.scrollGlobal.Paint = function(me, w, h)
    end
    local sbar = self.scrollGlobal:GetVBar()
    function sbar:Paint(w, h)
    end
    function sbar.btnUp:Paint(w, h)
    end
    function sbar.btnDown:Paint(w, h)
    end
    function sbar.btnGrip:Paint(w, h)
        draw.RoundedBox(8, w*0.5, 0, w * .4, h, LDT_Closetter.Config.Blue)
    end
end

function PANEL:GenerateGlobalPresets()
    self.scrollGlobal:Clear()

    self.globalPresetsBtns = {}
    for k, v in ipairs(self.parent.globalPresets) do
        self.globalPresetsBtns[k] = self.scrollGlobal:Add("DPanel")
        self.globalPresetsBtns[k]:SetTall(LDT_Closetter.GetWidth(40))
        self.globalPresetsBtns[k]:Dock(TOP)
        self.globalPresetsBtns[k]:DockMargin(0, LDT_Closetter.GetHeight(5), 0, 0)
        self.globalPresetsBtns[k]:DockPadding(LDT_Closetter.GetWidth(5), LDT_Closetter.GetHeight(5), LDT_Closetter.GetWidth(5), LDT_Closetter.GetHeight(5))
        self.globalPresetsBtns[k].presetID = v.PresetID
        self.globalPresetsBtns[k].Paint = function(me, w, h)
            draw.RoundedBox(8, 0, 0, w, h, LDT_Closetter.Config.Grey)
            draw.SimpleText(v.PresetName, "WorkSans26", w * 0.02, h * 0.5, LDT_Closetter.Config.White, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        end

        self.globalPresetsBtns[k].btn = self.globalPresetsBtns[k]:Add("DButton")
        self.globalPresetsBtns[k].btn:Dock(RIGHT)
        self.globalPresetsBtns[k].btn:SetWide(LDT_Closetter.GetWidth(100))
        self.globalPresetsBtns[k].btn:SetText("")
        self.globalPresetsBtns[k].btn.hovered = false
        self.globalPresetsBtns[k].btn.Paint = function(me, w, h)
            local color = LDT_Closetter.Config.Blue
            if me.hovered then
                color = LDT_Closetter.Config.BlueSecond
            end

            surface.SetFont("WorkSans26")
            local textWidth = surface.GetTextSize(LDT_Closetter.GetLanguage("LoadBtnText"))
            if textWidth > 100 then
                self.globalPresetsBtns[k].btn:SetWide(textWidth + LDT_Closetter.GetWidth(20))
            end

            draw.RoundedBox(6, 0, 0, w, h, color)
            draw.SimpleText(LDT_Closetter.GetLanguage("LoadBtnText"), "WorkSans26", w * 0.5, h * 0.5, LDT_Closetter.Config.White, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
        self.globalPresetsBtns[k].btn.OnCursorEntered = function(me)
            me.hovered = true
        end
        self.globalPresetsBtns[k].btn.OnCursorExited = function(me)
            me.hovered = false
        end
        self.globalPresetsBtns[k].btn.DoClick = function()
            net.Start("LDT_Closetter.LoadGlobalPreset")
                net.WriteUInt(v.PresetID, 22)
                net.WriteInt(self.parent.closetID, 9)
                net.WriteEntity(self.parent.ply)
            net.SendToServer()
        end

        if not LDT_Closetter.Config.AdminRanks[LDT_Closetter.GetPlayerGroup(self.parent.ply)] then continue end
        self.globalPresetsBtns[k].removeBtn = self.globalPresetsBtns[k]:Add("DImageButton")
        self.globalPresetsBtns[k].removeBtn:Dock(RIGHT)
        self.globalPresetsBtns[k].removeBtn:SetWide(LDT_Closetter.GetWidth(18))
        self.globalPresetsBtns[k].removeBtn:DockMargin(0, 0, LDT_Closetter.GetWidth(10), 0)
        self.globalPresetsBtns[k].removeBtn.DoClick = function()
            net.Start("LDT_Closetter.RemoveGlobalPreset")
                net.WriteUInt(v.PresetID, 22)
            net.SendToServer()
        end
        self.globalPresetsBtns[k].removeBtn.Paint = function(me, w, h)
            local drawColor = me.isHovered and LDT_Closetter.Config.Red or LDT_Closetter.Config.White
            surface.SetMaterial( LDT_Closetter.Materials.TrashCan )
            surface.SetDrawColor( drawColor )
            surface.DrawTexturedRect( 0, h * 0.5 - LDT_Closetter.GetHeight(18)/2, LDT_Closetter.GetWidth(18), LDT_Closetter.GetHeight(18) )
        end
        self.globalPresetsBtns[k].removeBtn.OnCursorEntered = function()
            self.globalPresetsBtns[k].removeBtn.isHovered = true
        end
        
        self.globalPresetsBtns[k].removeBtn.OnCursorExited = function()
            self.globalPresetsBtns[k].removeBtn.isHovered = false
        end
    end
end

function PANEL:LocalPresets()
    self.localPresetsTitle = self:Add("DPanel")
    self.localPresetsTitle:Dock(TOP)
    self.localPresetsTitle:SetTall(LDT_Closetter.GetHeight(40))
    self.localPresetsTitle.Paint = function(me, w, h)
        LDT_Closetter.DrawTopRoundedGradientBox(8, 0, 0, w, h*0.9, LDT_Closetter.Config.Grey, LDT_Closetter.Config.GreySecond, false)
        draw.RoundedBox(8, 0, h*0.9, w, h*0.1, LDT_Closetter.Config.Blue)
        draw.SimpleText(LDT_Closetter.GetLanguage("UserJobPresetsText"), "WorkSans30-Bold", w * 0.02, h * 0.475, LDT_Closetter.Config.White, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
    end

    self.scrollLocal = self:Add("DScrollPanel")
    self.scrollLocal:Dock(TOP)
    self.scrollLocal:SetTall(LDT_Closetter.GetHeight(335))
    self.scrollLocal:DockMargin(0, 0, 0, LDT_Closetter.GetHeight(10))
    self.scrollLocal.Paint = function(me, w, h)
    end
    local sbar = self.scrollLocal:GetVBar()
    function sbar:Paint(w, h)
    end
    function sbar.btnUp:Paint(w, h)
    end
    function sbar.btnDown:Paint(w, h)
    end
    function sbar.btnGrip:Paint(w, h)
        draw.RoundedBox(8, w*0.5, 0, w * .4, h, LDT_Closetter.Config.Blue)
    end
end

function PANEL:GenerateLocalPresets()
    self.scrollLocal:Clear()

    self.localPresetsBtns = {}
    for k, v in ipairs(LDT_Closetter.Presets) do
        if v.JobName ~= self.parent.job.name then continue end
        self.localPresetsBtns[k] = self.scrollLocal:Add("DPanel")
        self.localPresetsBtns[k]:SetTall(LDT_Closetter.GetWidth(40))
        self.localPresetsBtns[k]:Dock(TOP)
        self.localPresetsBtns[k]:DockMargin(0, LDT_Closetter.GetHeight(5), 0, 0)
        self.localPresetsBtns[k]:DockPadding(LDT_Closetter.GetWidth(5), LDT_Closetter.GetHeight(5), LDT_Closetter.GetWidth(5), LDT_Closetter.GetHeight(5))
        self.localPresetsBtns[k].presetID = v.PresetID
        self.localPresetsBtns[k].Paint = function(me, w, h)
            draw.RoundedBox(8, 0, 0, w, h, LDT_Closetter.Config.Grey)
            draw.SimpleText(v.PresetName, "WorkSans26", w * 0.02, h * 0.5, LDT_Closetter.Config.White, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        end

        self.localPresetsBtns[k].btn = self.localPresetsBtns[k]:Add("DButton")
        self.localPresetsBtns[k].btn:Dock(RIGHT)
        self.localPresetsBtns[k].btn:SetWide(LDT_Closetter.GetWidth(100))
        self.localPresetsBtns[k].btn:SetText("")
        self.localPresetsBtns[k].btn.hovered = false
        self.localPresetsBtns[k].btn.Paint = function(me, w, h)
            local color = LDT_Closetter.Config.Blue
            if me.hovered then
                color = LDT_Closetter.Config.BlueSecond
            end

            surface.SetFont("WorkSans26")
            local textWidth = surface.GetTextSize(LDT_Closetter.GetLanguage("LoadBtnText"))
            if textWidth > 100 then
                self.localPresetsBtns[k].btn:SetWide(textWidth + LDT_Closetter.GetWidth(20))
            end

            draw.RoundedBox(6, 0, 0, w, h, color)
            draw.SimpleText(LDT_Closetter.GetLanguage("LoadBtnText"), "WorkSans26", w * 0.5, h * 0.5, LDT_Closetter.Config.White, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
        self.localPresetsBtns[k].btn.OnCursorEntered = function(me)
            me.hovered = true
        end
        self.localPresetsBtns[k].btn.OnCursorExited = function(me)
            me.hovered = false
        end
        self.localPresetsBtns[k].btn.DoClick = function()
            LDT_Closetter.LoadPreset(v.PresetID, self.parent.closetID, self.parent.ply)
        end

        self.localPresetsBtns[k].removeBtn = self.localPresetsBtns[k]:Add("DImageButton")
        self.localPresetsBtns[k].removeBtn:Dock(RIGHT)
        self.localPresetsBtns[k].removeBtn:SetWide(LDT_Closetter.GetWidth(18))
        self.localPresetsBtns[k].removeBtn:DockMargin(0, 0, LDT_Closetter.GetWidth(10), 0)
        self.localPresetsBtns[k].removeBtn.DoClick = function()
            LDT_Closetter.RemovePreset(v.PresetID, function()
                self:GenerateLocalPresets()
            end)
        end
        self.localPresetsBtns[k].removeBtn.Paint = function(me, w, h)
            local drawColor = me.isHovered and LDT_Closetter.Config.Red or LDT_Closetter.Config.White
            surface.SetMaterial( LDT_Closetter.Materials.TrashCan )
            surface.SetDrawColor( drawColor )
            surface.DrawTexturedRect( 0, h * 0.5 - LDT_Closetter.GetHeight(18)/2, LDT_Closetter.GetWidth(18), LDT_Closetter.GetHeight(18) )
        end
        self.localPresetsBtns[k].removeBtn.OnCursorEntered = function()
            self.localPresetsBtns[k].removeBtn.isHovered = true
        end
        
        self.localPresetsBtns[k].removeBtn.OnCursorExited = function()
            self.localPresetsBtns[k].removeBtn.isHovered = false
        end
    end
end

function PANEL:Body()
    self:GlobalPresets()
    self:GenerateGlobalPresets()
    self:LocalPresets()
    self:GenerateLocalPresets()

    self.savePresetBtn = self:Add("DButton")
    self.savePresetBtn:Dock(BOTTOM)
    self.savePresetBtn:DockMargin(0, LDT_Closetter.GetHeight(5), 0, 0)
    self.savePresetBtn:SetTall(LDT_Closetter.GetHeight(35))
    self.savePresetBtn:SetText("")
    self.savePresetBtn.hovered = false
    self.savePresetBtn.Paint = function(me, w, h)
        local color = LDT_Closetter.Config.Blue
        if me.hovered then
            color = LDT_Closetter.Config.BlueSecond
        end
        draw.RoundedBox(8, 0, 0, w, h, color)
        draw.SimpleText(LDT_Closetter.GetLanguage("SaveJobPresetBtnText"), "WorkSans26", w * 0.5, h * 0.5, LDT_Closetter.Config.White, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    self.savePresetBtn.OnCursorEntered = function(me)
        me.hovered = true
    end
    self.savePresetBtn.OnCursorExited = function(me)
        me.hovered = false
    end
    self.savePresetBtn.DoClick = function()
        self.parent:SetMouseInputEnabled(false)

        self.presetPopUp = vgui.Create("LDT_Closetter_Popup_New_Preset")
        self.presetPopUp:Center()
        self.presetPopUp:MakePopup()
        self.presetPopUp:Show()
        self.presetPopUp:SetCallback(function(presetName)
            local jobName = self.parent.job.name
            local modelName = self.parent.center.model.Entity:GetModel()
            local skinID = self.parent.center.model.Entity:GetSkin()
            local bodygroups = {}
            for _, bodygroup in ipairs(self.parent.bodygroups) do
                bodygroups[bodygroup.id] = self.parent.center.model.Entity:GetBodygroup(bodygroup.id)
            end

            LDT_Closetter.SaveNewPreset(jobName, presetName, modelName, skinID, bodygroups, function()
                local k = #LDT_Closetter.Presets

                if LDT_Closetter.Presets[k] == nil then return end
                local presetID = LDT_Closetter.Presets[k].PresetID

                self.localPresetsBtns[k] = self.scrollLocal:Add("DPanel")
                self.localPresetsBtns[k]:SetTall(LDT_Closetter.GetWidth(40))
                self.localPresetsBtns[k]:Dock(TOP)
                self.localPresetsBtns[k]:DockMargin(0, LDT_Closetter.GetHeight(5), 0, 0)
                self.localPresetsBtns[k]:DockPadding(LDT_Closetter.GetWidth(5), LDT_Closetter.GetHeight(5), LDT_Closetter.GetWidth(5), LDT_Closetter.GetHeight(5))
                self.localPresetsBtns[k].presetID = presetID
                self.localPresetsBtns[k].Paint = function(me, w, h)
                    draw.RoundedBox(8, 0, 0, w, h, LDT_Closetter.Config.Grey)
                    draw.SimpleText(presetName, "WorkSans26", w * 0.02, h * 0.5, LDT_Closetter.Config.White, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
                end

                self.localPresetsBtns[k].btn = self.localPresetsBtns[k]:Add("DButton")
                self.localPresetsBtns[k].btn:Dock(RIGHT)
                self.localPresetsBtns[k].btn:SetWide(LDT_Closetter.GetWidth(100))
                self.localPresetsBtns[k].btn:SetText("")
                self.localPresetsBtns[k].btn.hovered = false
                self.localPresetsBtns[k].btn.Paint = function(me, w, h)
                    local color = LDT_Closetter.Config.Blue
                    if me.hovered then
                        color = LDT_Closetter.Config.BlueSecond
                    end
        
                    surface.SetFont("WorkSans26")
                    local textWidth = surface.GetTextSize(LDT_Closetter.GetLanguage("LoadBtnText"))
                    if textWidth > 100 then
                        self.localPresetsBtns[k].btn:SetWide(textWidth + LDT_Closetter.GetWidth(20))
                    end
        
                    draw.RoundedBox(6, 0, 0, w, h, color)
                    draw.SimpleText(LDT_Closetter.GetLanguage("LoadBtnText"), "WorkSans26", w * 0.5, h * 0.5, LDT_Closetter.Config.White, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                end
                self.localPresetsBtns[k].btn.OnCursorEntered = function(me)
                    me.hovered = true
                end
                self.localPresetsBtns[k].btn.OnCursorExited = function(me)
                    me.hovered = false
                end
                self.localPresetsBtns[k].btn.DoClick = function()
                    LDT_Closetter.LoadPreset(presetID, self.parent.closetID, self.parent.ply)
                end

                self.localPresetsBtns[k].removeBtn = self.localPresetsBtns[k]:Add("DImageButton")
                self.localPresetsBtns[k].removeBtn:Dock(RIGHT)
                self.localPresetsBtns[k].removeBtn:SetWide(LDT_Closetter.GetWidth(18))
                self.localPresetsBtns[k].removeBtn:DockMargin(0, 0, LDT_Closetter.GetWidth(10), 0)
                self.localPresetsBtns[k].removeBtn.DoClick = function()
                    LDT_Closetter.RemovePreset(presetID, function()
                        self:GenerateLocalPresets()
                    end)
                end
                self.localPresetsBtns[k].removeBtn.Paint = function(me, w, h)
                    local drawColor = me.isHovered and LDT_Closetter.Config.Red or LDT_Closetter.Config.White
                    surface.SetMaterial( LDT_Closetter.Materials.TrashCan )
                    surface.SetDrawColor( drawColor )
                    surface.DrawTexturedRect( 0, h * 0.5 - LDT_Closetter.GetHeight(18)/2, LDT_Closetter.GetWidth(18), LDT_Closetter.GetHeight(18) )
                end
                self.localPresetsBtns[k].removeBtn.OnCursorEntered = function()
                    self.localPresetsBtns[k].removeBtn.isHovered = true
                end
                
                self.localPresetsBtns[k].removeBtn.OnCursorExited = function()
                    self.localPresetsBtns[k].removeBtn.isHovered = false
                end
            end)

        end)
    end

    if LDT_Closetter.Config.AdminRanks[LDT_Closetter.GetPlayerGroup(self.parent.ply)] then
        self.saveGlobalSkinPresetBtn = self:Add("DButton")
        self.saveGlobalSkinPresetBtn:Dock(BOTTOM)
        self.saveGlobalSkinPresetBtn:DockMargin(0, LDT_Closetter.GetHeight(5), 0, 0)
        self.saveGlobalSkinPresetBtn:SetTall(LDT_Closetter.GetHeight(35))
        self.saveGlobalSkinPresetBtn:SetText("")
        self.saveGlobalSkinPresetBtn.hovered = false
        self.saveGlobalSkinPresetBtn.Paint = function(me, w, h)
            local color = LDT_Closetter.Config.Grey
            if me.hovered then
                color = LDT_Closetter.Config.GreyHover
            end
            draw.RoundedBox(8, 0, 0, w, h, color)
            draw.SimpleText(LDT_Closetter.GetLanguage("SaveServerJobPresetBtnText"), "WorkSans26", w * 0.5, h * 0.5, LDT_Closetter.Config.White, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
        self.saveGlobalSkinPresetBtn.OnCursorEntered = function(me)
            me.hovered = true
        end
        self.saveGlobalSkinPresetBtn.OnCursorExited = function(me)
            me.hovered = false
        end
        self.saveGlobalSkinPresetBtn.DoClick = function()
            self.parent:SetMouseInputEnabled(false)

            self.presetPopUp = vgui.Create("LDT_Closetter_Popup_New_Preset")
            self.presetPopUp:Center()
            self.presetPopUp:MakePopup()
            self.presetPopUp:Show()
            self.presetPopUp:SetCallback(function(presetName)
                net.Start("LDT_Closetter.SaveGlobalPreset")
                    net.WriteString(presetName)
                    net.WriteString(self.parent.center.model.Entity:GetModel())
                    net.WriteUInt(self.parent.center.model.Entity:GetSkin(), 6)
                    net.WriteUInt(#self.parent.bodygroups, 8)
                    for _, bodygroup in pairs(self.parent.bodygroups) do
                        net.WriteUInt(bodygroup.id, 8)
                        net.WriteUInt(self.parent.center.model.Entity:GetBodygroup(bodygroup.id), 6)
                    end
                net.SendToServer()
            end)
        end
    end
end

-- Change the defualt paint.
function PANEL:Paint(w, h)
end

vgui.Register("LDT_Closetter_Left_Panel", PANEL, "DPanel")