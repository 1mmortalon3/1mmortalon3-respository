local PANEL = {}

-- Setup default properties of this panel
function PANEL:Init()
    self:SetDraggable(false)
    self:SetTitle("")
    self:DockPadding(0, 0, 0, 0)
    self:ShowCloseButton(false)
    self:SetSize( LDT_Closetter.GetWidth(800), LDT_Closetter.GetHeight(350) )
    self.startTime = SysTime()
end

function PANEL:SetData(data)
    self.data = data

    self:TopBar()
    self:Body()
end

function PANEL:TopBar() 
    self.topbar = self:Add("DPanel")
    self.topbar:Dock(TOP)
    self.topbar:SetTall(LDT_Closetter.GetHeight(50))
    self.topbar.Paint = function(me,w,h)
        draw.RoundedBoxEx(8, 0, 0, w, h, LDT_Closetter.Config.Blue, true, true, false, false)
        draw.SimpleText(LDT_Closetter.GetLanguage("CloneBodygroupsTitle"), "WorkSans36-Bold", w * 0 + LDT_Closetter.GetWidth(10), h * .5, LDT_Closetter.Config.White, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
    end
end

function PANEL:Body()
    self.body = self:Add("DPanel")
    self.body:Dock(FILL)
    self.body:DockMargin(LDT_Closetter.GetWidth(10), LDT_Closetter.GetHeight(10), LDT_Closetter.GetWidth(10), LDT_Closetter.GetHeight(10))
    self.body.Paint = function(me,w,h)
    end

    if #self.data == 0 then
        self.noUsers = self.body:Add("DPanel")
        self.noUsers:Dock(TOP)
        self.noUsers:SetTall(LDT_Closetter.GetHeight(50))
        self.noUsers.Paint = function(me, w, h)
            draw.RoundedBox(8, 0, 0, w, h, LDT_Closetter.Config.GreySecond)
            draw.SimpleText(LDT_Closetter.GetLanguage("NoUsersFoundText"), "WorkSans30", w * 0.5, h * 0.5, LDT_Closetter.Config.White, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
    else 
        self.scroll = self.body:Add("DScrollPanel")
        self.scroll:Dock(FILL)
        self.scroll:DockMargin(0, 0, 0, LDT_Closetter.GetHeight(5))
        self.scroll.Paint = function(me, w, h)
        end
        local sbar = self.scroll:GetVBar()
        function sbar:Paint(w, h)
        end
        function sbar.btnUp:Paint(w, h)
        end
        function sbar.btnDown:Paint(w, h)
        end
        function sbar.btnGrip:Paint(w, h)
            draw.RoundedBox(8, w*0.5, 0, w * .4, h, LDT_Closetter.Config.Blue)
        end

        self.userPanels = {}
        for k, v in ipairs(self.data) do
            self.userPanels[k] = self.scroll:Add("DPanel")
            self.userPanels[k]:Dock(TOP)
            self.userPanels[k]:DockMargin(0, 0, 0, LDT_Closetter.GetHeight(5))
            self.userPanels[k]:SetTall(LDT_Closetter.GetHeight(50))
            self.userPanels[k].Paint = function(me, w, h)
                draw.RoundedBox(8, 0, 0, w, h, LDT_Closetter.Config.GreySecond)
                steamworks.RequestPlayerInfo( v, function( steamName )
                    draw.SimpleText(steamName, "WorkSans30", w * 0.02, h * 0.475, LDT_Closetter.Config.White, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
                end )
            end
        
            self.userPanels[k].cloneBtn = self.userPanels[k]:Add("DButton")
            self.userPanels[k].cloneBtn:Dock(RIGHT)
            self.userPanels[k].cloneBtn:SetWide(LDT_Closetter.GetWidth(100))
            self.userPanels[k].cloneBtn:DockMargin(LDT_Closetter.GetWidth(5), LDT_Closetter.GetHeight(5), LDT_Closetter.GetWidth(5), LDT_Closetter.GetHeight(5))
            self.userPanels[k].cloneBtn:SetText("")
            self.userPanels[k].cloneBtn.hovered = false
            self.userPanels[k].cloneBtn.Paint = function(me,w,h)
                local color = LDT_Closetter.Config.Blue
                if me.hovered then
                    color = LDT_Closetter.Config.BlueSecond
                end

                surface.SetFont("WorkSans26")
                local textWidth = surface.GetTextSize(LDT_Closetter.GetLanguage("CloneBtnText"))
                if textWidth > 100 then
                    self.userPanels[k].cloneBtn:SetWide(textWidth + LDT_Closetter.GetWidth(20))
                end

                draw.RoundedBox(8, 0, 0, w, h, color)
                draw.SimpleText(LDT_Closetter.GetLanguage("CloneBtnText"), "WorkSans26", w * 0.5, h * 0.5, LDT_Closetter.Config.White, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            end
            self.userPanels[k].cloneBtn.OnCursorEntered = function(me)
                me.hovered = true
            end
            self.userPanels[k].cloneBtn.OnCursorExited = function(me)
                me.hovered = false
            end
            self.userPanels[k].cloneBtn.DoClick = function()
                net.Start("LDT_Closetter.CloneBodygroups")
                    net.WriteInt(LDT_Closetter.closetMainPanel.closetID, 9)
                    net.WriteString(v)
                net.SendToServer()
                LDT_Closetter.closetMainPanel:SetMouseInputEnabled(true)
                self:Close()
            end
        end
    end

    self.closeBtn = self.body:Add("DButton")
    self.closeBtn:Dock(BOTTOM)
    self.closeBtn:DockMargin(0, LDT_Closetter.GetHeight(5), 0, 0)
    self.closeBtn:SetTall(LDT_Closetter.GetHeight(35))
    self.closeBtn:SetText("")
    self.closeBtn.hovered = false
    self.closeBtn.Paint = function(me,w,h)
        local color = LDT_Closetter.Config.Red
        if me.hovered then
            color = LDT_Closetter.Config.RedHover
        end
        draw.RoundedBox(8, 0, 0, w, h, color)
        draw.SimpleText(LDT_Closetter.GetLanguage("CloseBtnText"), "WorkSans26", w * 0.5, h * 0.5, LDT_Closetter.Config.White, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    self.closeBtn.OnCursorEntered = function(me)
        me.hovered = true
    end
    self.closeBtn.OnCursorExited = function(me)
        me.hovered = false
    end
    self.closeBtn.DoClick = function()
        LDT_Closetter.closetMainPanel:SetMouseInputEnabled(true)
        self:Close()
    end
end

-- Change the defualt paint.
function PANEL:Paint(w, h)
    Derma_DrawBackgroundBlur(self, self.startTime)
    draw.RoundedBox( 8, 0, 0, w, h, LDT_Closetter.Config.Grey )
end

vgui.Register("LDT_Closetter_Clone_From_Users", PANEL, "DFrame")