local PANEL = {}

-- Setup default properties of this panel
function PANEL:Init()
    self:SetDraggable(false)
    self:SetTitle("")
    self:DockPadding(0, 0, 0, 0)
    self:ShowCloseButton(false)
    self:SetSize( LDT_Closetter.GetWidth(1500), LDT_Closetter.GetHeight(900) )
end

function PANEL:SetData(closetID, globalPresets,ply)
    self.closetID = closetID
    self.globalPresets = globalPresets
    self.ply = ply

    self:TopBar()
    self:CloseButton()
    self:CenterPanel()
    self:RightPanel()
    self:LeftPanel()
end

function PANEL:LeftPanel()
    self.left = self:Add("LDT_Closetter_Left_Panel")
end

function PANEL:CenterPanel()
    self.center = self:Add("LDT_Closetter_Center_Panel")
end

function PANEL:RightPanel()
    if IsValid(self.right) then self.right:Remove() end

    self.right = self:Add("LDT_Closetter_Right_Panel")
end

function PANEL:TopBar() 
    self.topbar = self:Add("DPanel")
    self.topbar:Dock(TOP)
    self.topbar:SetTall(LDT_Closetter.GetHeight(50))
    self.topbar.Paint = function(me,w,h)
        draw.RoundedBoxEx(8, 0, 0, w, h, LDT_Closetter.Config.Blue, true, true, false, false)
        draw.SimpleText("Closet", "WorkSans36-Bold", w * 0 + LDT_Closetter.GetWidth(10), h * .5, LDT_Closetter.Config.White, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
    end
end

-- Create the close button
function PANEL:CloseButton()
    if IsValid(self.closeBtn) then self.closeBtn:Remove() end
    
    self.closeBtn = self.topbar:Add("DImageButton")
    self.closeBtn:Dock(RIGHT)
    self.closeBtn:SetWide(LDT_Closetter.GetWidth(18))
    self.closeBtn:DockMargin(0, LDT_Closetter.GetHeight(16), LDT_Closetter.GetWidth(10), LDT_Closetter.GetHeight(16))
    self.closeBtn.DoClick = function()
        self:Remove()
    end
    self.closeBtn.Paint = function(me, w, h)
        surface.SetMaterial( LDT_Closetter.Materials.XIcon )
        surface.SetDrawColor( LDT_Closetter.Config.Red )
        surface.DrawTexturedRect( 0, h * 0.5 - LDT_Closetter.GetHeight(18)/2, LDT_Closetter.GetWidth(18), LDT_Closetter.GetHeight(18) )
    end
end

function PANEL:RandomizeBodygroups(newBodygroups)
    local count = 0
    for k, v in pairs(newBodygroups) do
        count = count + 1
        self.center.model.Entity:SetBodygroup(k, v)
    end

    net.Start("LDT_Closetter.RandomizeBodygroups")
        net.WriteInt(self.closetID, 9)
        net.WriteUInt(count, 6)
        for k, v in pairs(newBodygroups) do
            net.WriteUInt(k, 6)
            net.WriteUInt(v, 6)
        end
        net.WriteEntity(self.ply)
    net.SendToServer()
end

function PANEL:SetNewBodygroup(id, value)
    self.center.model.Entity:SetBodygroup(id, value)

    net.Start("LDT_Closetter.SetBodygroup")
        net.WriteInt(self.closetID, 9)
        net.WriteUInt(id, 6)
        net.WriteUInt(value, 6)
        net.WriteEntity(self.ply)
    net.SendToServer()
end

function PANEL:SetNewModel(model)
    net.Start("LDT_Closetter.SetModel")
        net.WriteInt(self.closetID, 9)
        net.WriteString(model)
        net.WriteEntity(self.ply)
    net.SendToServer()
end

function PANEL:SetNewSkin(skinID)
    self.center.model.Entity:SetSkin(skinID)

    net.Start("LDT_Closetter.SetSkin")
        net.WriteInt(self.closetID, 9)
        net.WriteUInt(skinID, 6)
        net.WriteEntity(self.ply)
    net.SendToServer()
end

function PANEL:AddNewGlobalPreset(presetName, presetID)
    table.insert(self.globalPresets, {PresetID = presetID, PresetName = presetName})

    local k = #self.left.globalPresetsBtns + 1
    self.left.globalPresetsBtns[k] = self.left.scrollGlobal:Add("DPanel")
    self.left.globalPresetsBtns[k]:SetTall(LDT_Closetter.GetWidth(40))
    self.left.globalPresetsBtns[k]:Dock(TOP)
    self.left.globalPresetsBtns[k]:DockMargin(0, LDT_Closetter.GetHeight(5), 0, 0)
    self.left.globalPresetsBtns[k]:DockPadding(LDT_Closetter.GetWidth(5), LDT_Closetter.GetHeight(5), LDT_Closetter.GetWidth(5), LDT_Closetter.GetHeight(5))
    self.left.globalPresetsBtns[k].presetID = presetID
    self.left.globalPresetsBtns[k].Paint = function(me, w, h)
        draw.RoundedBox(8, 0, 0, w, h, LDT_Closetter.Config.Grey)
        draw.SimpleText(presetName, "WorkSans26", w * 0.02, h * 0.5, LDT_Closetter.Config.White, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
    end

    self.left.globalPresetsBtns[k].btn = self.left.globalPresetsBtns[k]:Add("DButton")
    self.left.globalPresetsBtns[k].btn:Dock(RIGHT)
    self.left.globalPresetsBtns[k].btn:SetWide(LDT_Closetter.GetWidth(100))
    self.left.globalPresetsBtns[k].btn:SetText("")
    self.left.globalPresetsBtns[k].btn.hovered = false
    self.left.globalPresetsBtns[k].btn.Paint = function(me, w, h)
        local color = LDT_Closetter.Config.Blue
        if me.hovered then
            color = LDT_Closetter.Config.BlueSecond
        end

        surface.SetFont("WorkSans26")
        local textWidth = surface.GetTextSize(LDT_Closetter.GetLanguage("LoadBtnText"))
        if textWidth > 100 then
            self.globalPresetsBtns[k].btn:SetWide(textWidth + LDT_Closetter.GetWidth(20))
        end

        draw.RoundedBox(6, 0, 0, w, h, color)
        draw.SimpleText(LDT_Closetter.GetLanguage("LoadBtnText"), "WorkSans26", w * 0.5, h * 0.5, LDT_Closetter.Config.White, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    self.left.globalPresetsBtns[k].btn.OnCursorEntered = function(me)
        me.hovered = true
    end
    self.left.globalPresetsBtns[k].btn.OnCursorExited = function(me)
        me.hovered = false
    end
    self.left.globalPresetsBtns[k].btn.DoClick = function()
        net.Start("LDT_Closetter.LoadGlobalPreset")
            net.WriteUInt(presetID, 22)
            net.WriteInt(self.closetID, 9)
            net.WriteEntity(self.ply)
        net.SendToServer()
    end

    if not LDT_Closetter.Config.AdminRanks[LDT_Closetter.GetPlayerGroup(self.ply)] then return end
    self.left.globalPresetsBtns[k].removeBtn = self.left.globalPresetsBtns[k]:Add("DImageButton")
    self.left.globalPresetsBtns[k].removeBtn:Dock(RIGHT)
    self.left.globalPresetsBtns[k].removeBtn:SetWide(LDT_Closetter.GetWidth(18))
    self.left.globalPresetsBtns[k].removeBtn:DockMargin(0, 0, LDT_Closetter.GetWidth(10), 0)
    self.left.globalPresetsBtns[k].removeBtn.DoClick = function()
        net.Start("LDT_Closetter.RemoveGlobalPreset")
            net.WriteUInt(presetID, 22)
        net.SendToServer()
    end
    self.left.globalPresetsBtns[k].removeBtn.Paint = function(me, w, h)
        local drawColor = me.isHovered and LDT_Closetter.Config.Red or LDT_Closetter.Config.White
        surface.SetMaterial( LDT_Closetter.Materials.TrashCan )
        surface.SetDrawColor( drawColor )
        surface.DrawTexturedRect( 0, h * 0.5 - LDT_Closetter.GetHeight(18)/2, LDT_Closetter.GetWidth(18), LDT_Closetter.GetHeight(18) )
    end
    self.left.globalPresetsBtns[k].removeBtn.OnCursorEntered = function()
        self.left.globalPresetsBtns[k].removeBtn.isHovered = true
    end
    
    self.left.globalPresetsBtns[k].removeBtn.OnCursorExited = function()
        self.left.globalPresetsBtns[k].removeBtn.isHovered = false
    end
end

function PANEL:RemoveGlobalPreset(presetID)
    for k, v in ipairs(self.globalPresets) do
        if v.PresetID == presetID then
            table.remove(self.globalPresets, k)
            break
        end
    end

    self.left:GenerateGlobalPresets()
end

-- Change the defualt paint.
function PANEL:Paint(w, h)
    draw.RoundedBox( 8, 0, 0, w, h, LDT_Closetter.Config.GreyTrans )
end

vgui.Register("LDT_Closetter_Frame", PANEL, "DFrame")