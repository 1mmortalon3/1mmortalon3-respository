local PANEL = {}

local xicon = Material("ldt_closetter/x.png", "noclamp smooth")
local gradientDown = Material("gui/gradient_down", "noclamp smooth")

-- Setup default properties of this panel
function PANEL:Init()
    self:Dock(FILL)

    self.parent = self:GetParent()
    self:Body()
end

function PANEL:Body()
    self.model = self:Add("DModelPanel")
    self.model:Dock(FILL)
    self.model:SetModel(self.parent.ply:GetModel())
    self.model:SetLookAt(Vector(0, 0, 36))
    self.model:SetCamPos(Vector(64, 0, 36))
    self.model.Entity:SetEyeTarget(self.model.Entity:GetPos() + Vector(150, 0, 50))
    self.model:SetDirectionalLight(BOX_TOP, Color(172, 146, 68))
    self.model:SetCursor("sizeall")

    self.model.rotation = 90
    self.model.fieldOfView = 25
    self.model:SetFOV(self.model.fieldOfView)
    self.model.isDragging = false
    self.model.isDraggingRight = false
    self.model.startMouseX = 0
    self.model.startMouseY = 0
    self.model.rotationMultiplier = 0.4
    self.model.zoomMultiplier = 0.09
    self.model.xOffset = 0
    self.model.yOffset = 0

    function self.model:LayoutEntity(entity)
        local rotation = self.rotation
        local fieldOfView = self:GetFOV()
        local xOffset = self.xOffset
        local yOffset = self.yOffset

        if self.isDragging then
            rotation = self.rotation + (gui.MouseX() - self.startMouseX) * self.rotationMultiplier
            fieldOfView = math.Clamp(self.fieldOfView + (self.startMouseY - gui.MouseY()) * self.zoomMultiplier, 20, 65)
        end

        if self.isDraggingRight then
            xOffset = math.Clamp(self.xOffset + (self.startMouseX - gui.MouseX()) * 0.02, -16, 16)
            yOffset = math.Clamp(self.yOffset + (self.startMouseY - gui.MouseY()) * 0.02, -16, 16)
        end

        entity:SetAngles(Angle(0, 0, 0))
        self:SetFOV(fieldOfView)

        local fraction = LDT_Closetter.InverseLerp(fieldOfView, 75, 20)
        local height = Lerp(fraction, 36, 64)
        local normalized = (self:GetCamPos() - Vector(0, 0, 64)):GetNormalized()
        local lookAngle = normalized:Angle()
        local cameraOffset = Vector(0, 0, yOffset * 2 * (1 - fraction)) + lookAngle:Right() * xOffset * 2 * (1 - fraction)

        self:SetLookAt(Vector(0, 0, height - 2 * fraction) - cameraOffset)
        self:SetCamPos(Vector(64 * math.sin(rotation * math.pi / 180), 64 * math.cos(rotation * math.pi / 180), height + 4 * (1 - fraction)) - cameraOffset)
    end

    function self.model:OnMousePressed(mouseButton)
        self.startMouseX = gui.MouseX()
        self.startMouseY = gui.MouseY()
        self.isDragging = (mouseButton == MOUSE_LEFT)
        self.isDraggingRight = (mouseButton == MOUSE_RIGHT)
    end

    function self.model:OnMouseReleased()
        if self.isDragging then
            self.rotation = self.rotation + (gui.MouseX() - self.startMouseX) * self.rotationMultiplier
            self.fieldOfView = math.Clamp(self.fieldOfView + (self.startMouseY - gui.MouseY()) * self.zoomMultiplier, 20, 75)
        end

        if self.isDraggingRight then
            self.xOffset = math.Clamp(self.xOffset + (self.startMouseX - gui.MouseX()) * 0.02, -16, 16)
            self.yOffset = math.Clamp(self.yOffset + (self.startMouseY - gui.MouseY()) * 0.02, -16, 16)
        end

        self.isDragging = false
        self.isDraggingRight = false
    end

    function self.model:OnCursorExited()
        if self.isDragging or self.isDraggingRight then
            self:OnMouseReleased()
        end
    end

    function self.model:OnMouseWheeled(delta)
        self.fieldOfView = math.Clamp(self.fieldOfView - delta * 2, 20, 65)
        self:SetFOV(self.fieldOfView)
        return true
    end

    if LDT_Closetter.Config.EnableRandomize then
        self.randomizerBtn = self:Add("DButton")
        self.randomizerBtn:SetPos(LDT_Closetter.GetWidth(350) - (LDT_Closetter.GetWidth(LDT_Closetter.GetWidth(50)))/2, LDT_Closetter.GetHeight(810))
        self.randomizerBtn:SetSize(LDT_Closetter.GetWidth(LDT_Closetter.GetWidth(100)), LDT_Closetter.GetHeight(35))
        self.randomizerBtn:SetText("")
        self.randomizerBtn.hovered = false
        self.randomizerBtn.Paint = function(me, w, h)
            local color = LDT_Closetter.Config.Grey
            if me.hovered then
                color = LDT_Closetter.Config.GreyHover
            end

            surface.SetFont("WorkSans26")
            local textWidth = surface.GetTextSize(LDT_Closetter.GetLanguage("RandomizeBtnText"))
            self.randomizerBtn:SetWide(textWidth + LDT_Closetter.GetWidth(50))
            self.randomizerBtn:SetPos(LDT_Closetter.GetWidth(350) - (LDT_Closetter.GetWidth(textWidth+LDT_Closetter.GetWidth(50)))/2, LDT_Closetter.GetHeight(810))

            draw.RoundedBox(8, 0, 0, w, h, color)
            draw.SimpleText(LDT_Closetter.GetLanguage("RandomizeBtnText"), "WorkSans26", w * 0.5, h * 0.5, LDT_Closetter.Config.White, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
        self.randomizerBtn.OnCursorEntered = function(me)
            me.hovered = true
        end
        self.randomizerBtn.OnCursorExited = function(me)
            me.hovered = false
        end
        self.randomizerBtn.DoClick = function()
            self.parent:SetNewSkin(math.random(0, self.model.Entity:SkinCount() - 1))
            local bodygroups = {}
            for _, bodygroup in ipairs(self.parent.bodygroups) do
                bodygroups[bodygroup.id] = math.random(0, bodygroup.num-1)
                self.parent:SetNewBodygroup(bodygroup.id, bodygroups[bodygroup.id])
            end

            self.parent:RandomizeBodygroups(bodygroups)
        end
    end
end

-- Change the defualt paint.
function PANEL:Paint(w, h)
end

vgui.Register("LDT_Closetter_Center_Panel", PANEL, "DPanel")