local PANEL = {}

-- Setup default properties of this panel
function PANEL:Init()
    self:DockMargin(0, LDT_Closetter.GetHeight(5), 0, LDT_Closetter.GetHeight(25))
    self:Dock(TOP)

	self:SetSpaceX( LDT_Closetter.GetWidth(5) )
	self:SetSpaceY( LDT_Closetter.GetHeight(5) )
end

function PANEL:SetData(data, callback, verificationTable)
    self.data = data
    self.callback = callback
    self.verificationTable = verificationTable
    self:DrawBtns()
end

function PANEL:DrawBtns()
    self.btns = {}
    local parentWidth = LDT_Closetter.GetWidth(400)
    for k, v in pairs(self.data) do
        if self.verificationTable then
            if not self.verificationTable[k+1] then continue end
        end

        self.btns[k] = self:Add("DButton")
        self.btns[k]:SetSize(((parentWidth-LDT_Closetter.GetWidth(30))/4), LDT_Closetter.GetHeight(28))
        self.btns[k]:SetText("")
        self.btns[k].hovered = false
        self.btns[k].Paint = function(me, w, h)
            local color = LDT_Closetter.Config.Blue
            if me.hovered then
                color = LDT_Closetter.Config.BlueSecond
            end
            draw.RoundedBox(8, 0, 0, w, h, color)
            draw.SimpleText(k, "WorkSans26", w * 0.5, h * 0.5, LDT_Closetter.Config.White, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
        self.btns[k].OnCursorEntered = function(me)
            me.hovered = true
        end
        self.btns[k].OnCursorExited = function(me)
            me.hovered = false
        end
        self.btns[k].DoClick = function()
            self.callback(k)
        end
    end
end

-- Change the defualt paint.
function PANEL:Paint(w, h)
end

vgui.Register("LDT_Closetter_Btn_Panel", PANEL, "DIconLayout")