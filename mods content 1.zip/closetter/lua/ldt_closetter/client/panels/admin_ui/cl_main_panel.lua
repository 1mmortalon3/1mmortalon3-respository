local PANEL = {}

-- Setup default properties of this panel
function PANEL:Init()
    self:SetDraggable(false)
    self:SetTitle("")
    self:DockPadding(0, 0, 0, 0)
    self:ShowCloseButton(false)
    self:SetSize( LDT_Closetter.GetWidth(900), LDT_Closetter.GetHeight(500) )

    self:TopBar()
    self:CloseButton()
    self:Body()
end

function PANEL:Body()
    self.body = self:Add("DPanel")
    self.body:Dock(FILL)
    self.body:DockMargin(LDT_Closetter.GetWidth(10), LDT_Closetter.GetHeight(10), LDT_Closetter.GetWidth(10), LDT_Closetter.GetHeight(10))
    self.body.Paint = function(me,w,h)
    end

    self.scroll = self.body:Add("DScrollPanel")
    self.scroll:Dock(FILL)
    self.scroll.Paint = function(me,w,h)
    end
    local sbar = self.scroll:GetVBar()
    function sbar:Paint(w, h)
    end
    function sbar.btnUp:Paint(w, h)
    end
    function sbar.btnDown:Paint(w, h)
    end
    function sbar.btnGrip:Paint(w, h)
        draw.RoundedBox(8, w*0.5, 0, w * .4, h, LDT_Closetter.Config.Blue)
    end

    self.playerPanels = {}
    for k, v in ipairs(player.GetAll()) do
        if v == LocalPlayer() then continue end

        self.playerPanels[k] = self.scroll:Add("DPanel")
        self.playerPanels[k]:Dock(TOP)
        self.playerPanels[k]:SetTall(LDT_Closetter.GetHeight(50))
        self.playerPanels[k]:DockMargin(0, 0, 0, LDT_Closetter.GetHeight(5))
        self.playerPanels[k].Paint = function(me, w, h)
            draw.RoundedBox(8, 0, 0, w, h, LDT_Closetter.Config.GreySecond)
            draw.SimpleText(v:Nick(), "WorkSans26", w * 0.02, h * 0.475, LDT_Closetter.Config.White, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        end

        self.playerPanels[k].editBtn = self.playerPanels[k]:Add("DButton")
        self.playerPanels[k].editBtn:Dock(RIGHT)
        self.playerPanels[k].editBtn:SetWide(LDT_Closetter.GetWidth(163))
        self.playerPanels[k].editBtn:SetText("")
        self.playerPanels[k].editBtn:DockMargin(LDT_Closetter.GetWidth(5), LDT_Closetter.GetHeight(5), LDT_Closetter.GetWidth(5), LDT_Closetter.GetHeight(5))
        self.playerPanels[k].editBtn.hovered = false
        self.playerPanels[k].editBtn.Paint = function(me, w, h)
            local color = LDT_Closetter.Config.Blue
            if me.hovered then
                color = LDT_Closetter.Config.BlueSecond
            end

            surface.SetFont("WorkSans26")
            local textWidth = surface.GetTextSize(LDT_Closetter.GetLanguage("EditBodygroupsBtnText"))
            if textWidth > 143 then
                self.playerPanels[k].editBtn:SetWide(textWidth + LDT_Closetter.GetWidth(20))
            end
            
            draw.RoundedBox(8, 0, 0, w, h, color)
            draw.SimpleText(LDT_Closetter.GetLanguage("EditBodygroupsBtnText"), "WorkSans26", w * 0.5, h * 0.5, LDT_Closetter.Config.White, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
        self.playerPanels[k].editBtn.OnCursorEntered = function(me)
            me.hovered = true
        end
        self.playerPanels[k].editBtn.OnCursorExited = function(me)
            me.hovered = false
        end
        self.playerPanels[k].editBtn.DoClick = function()
            net.Start("LDT_Closetter.EditOtherUser")
                net.WriteEntity(v)
            net.SendToServer()
        end
    end

    if #self.playerPanels == 0 then
        self.noUsers = self.scroll:Add("DPanel")
        self.noUsers:Dock(TOP)
        self.noUsers:SetTall(LDT_Closetter.GetHeight(50))
        self.noUsers.Paint = function(me, w, h)
            draw.RoundedBox(8, 0, 0, w, h, LDT_Closetter.Config.GreySecond)
            draw.SimpleText(LDT_Closetter.GetLanguage("NoUsersFoundText"), "WorkSans30", w * 0.5, h * 0.5, LDT_Closetter.Config.White, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
    end


    self.deleteClosetsWithoutSaving = self.body:Add("DButton")
    self.deleteClosetsWithoutSaving:Dock(BOTTOM)
    self.deleteClosetsWithoutSaving:SetTall(LDT_Closetter.GetHeight(35))
    self.deleteClosetsWithoutSaving:DockMargin(0, LDT_Closetter.GetHeight(5), 0, 0)
    self.deleteClosetsWithoutSaving:SetText("")
    self.deleteClosetsWithoutSaving.hovered = false
    self.deleteClosetsWithoutSaving.Paint = function(me, w, h)
        local color = LDT_Closetter.Config.Red
        if me.hovered then
            color = LDT_Closetter.Config.RedHover
        end
        draw.RoundedBox(8, 0, 0, w, h, color)
        draw.SimpleText(LDT_Closetter.GetLanguage("DeleteWithoutSavingBtnText"), "WorkSans26", w * 0.5, h * 0.5, LDT_Closetter.Config.White, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    self.deleteClosetsWithoutSaving.OnCursorEntered = function(me)
        me.hovered = true
    end
    self.deleteClosetsWithoutSaving.OnCursorExited = function(me)
        me.hovered = false
    end
    self.deleteClosetsWithoutSaving.DoClick = function()
        net.Start("LDT_Closetter.DeleteClosetsWithoutSaving")
        net.SendToServer()
    end

    self.loadClosets = self.body:Add("DButton")
    self.loadClosets:Dock(BOTTOM)
    self.loadClosets:SetTall(LDT_Closetter.GetHeight(35))
    self.loadClosets:SetText("")
    self.loadClosets.hovered = false
    self.loadClosets.Paint = function(me, w, h)
        local color = LDT_Closetter.Config.Blue
        if me.hovered then
            color = LDT_Closetter.Config.BlueSecond
        end
        draw.RoundedBox(8, 0, 0, w, h, color)
        draw.SimpleText(LDT_Closetter.GetLanguage("LoadClosetsBtnText"), "WorkSans26", w * 0.5, h * 0.5, LDT_Closetter.Config.White, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    self.loadClosets.OnCursorEntered = function(me)
        me.hovered = true
    end
    self.loadClosets.OnCursorExited = function(me)
        me.hovered = false
    end
    self.loadClosets.DoClick = function()
        net.Start("LDT_Closetter.LoadClosets")
        net.SendToServer()
    end
end

function PANEL:TopBar() 
    self.topbar = self:Add("DPanel")
    self.topbar:Dock(TOP)
    self.topbar:SetTall(LDT_Closetter.GetHeight(50))
    self.topbar.Paint = function(me,w,h)
        draw.RoundedBoxEx(8, 0, 0, w, h, LDT_Closetter.Config.Blue, true, true, false, false)
        draw.SimpleText(LDT_Closetter.GetLanguage("ClosetterAdminMenuTitle"), "WorkSans36-Bold", w * 0 + LDT_Closetter.GetWidth(10), h * .5, LDT_Closetter.Config.White, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
    end
end

-- Create the close button
function PANEL:CloseButton()
    if IsValid(self.closeBtn) then self.closeBtn:Remove() end
    
    self.closeBtn = self.topbar:Add("DImageButton")
    self.closeBtn:Dock(RIGHT)
    self.closeBtn:SetWide(LDT_Closetter.GetWidth(18))
    self.closeBtn:DockMargin(0, LDT_Closetter.GetHeight(16), LDT_Closetter.GetWidth(10), LDT_Closetter.GetHeight(16))
    self.closeBtn.DoClick = function()
        self:Remove()
    end
    self.closeBtn.Paint = function(me, w, h)
        surface.SetMaterial( LDT_Closetter.Materials.XIcon )
        surface.SetDrawColor( LDT_Closetter.Config.Red )
        surface.DrawTexturedRect( 0, h * 0.5 - LDT_Closetter.GetHeight(18)/2, LDT_Closetter.GetWidth(18), LDT_Closetter.GetHeight(18) )
    end
end

-- Change the defualt paint.
function PANEL:Paint(w, h)
    draw.RoundedBox( 8, 0, 0, w, h, LDT_Closetter.Config.Grey )
end

vgui.Register("LDT_Closetter_Admin_Frame", PANEL, "DFrame")