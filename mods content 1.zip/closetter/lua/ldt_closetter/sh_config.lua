LDT_Closetter = LDT_Closetter or {}
LDT_Closetter.Config = LDT_Closetter.Config or {}

LDT_Closetter.Config.Language = "en" -- Currently there are en, fr, pl, de, sp, it and ru translations available.

LDT_Closetter.Config.AdminRanks = {
    ["superadmin"] = true,
    ["admin"] = true
} -- These are the ranks that can spawn new closets. You can add more ranks if you want to.

LDT_Closetter.Config.ContextMenuRanks = {
    ["superadmin"] = true,
    ["admin"] = true
} -- These are the ranks that can open the closet from the context menu. You can add more ranks if you want to.

LDT_Closetter.Config.ContextMenuJobs = {
    ["Admin Job"] = true,
} -- These are the ranks that can open the closet from the context menu. You can add more ranks if you want to.

LDT_Closetter.Config.OpenFromContextMenuOverride = true -- If this is set to true anyone can open the closet from the context menu.

-- If this is set to true, then players can open the closetter menu using chat commands.
-- THE PERMISSIONS FOR CONTEXT MENU AND COMMANDS ARE SHARED!
LDT_Closetter.Config.EnableOpeningClosetterUsingCommand = true
LDT_Closetter.Config.OpenClosetterCommand = '!closetter'


-- To block bodygroups or skins you need to modify your DarkRP jobs.
-- Here is an example of how to block bodygroups and skins for a template job:
--[[TEAM_TEMPLATE = DarkRP.createJob("TEMPLATE JOB", {
    color = Color(20, 150, 20, 255),
    model = {
        // SOME PLAYERMODELS
    },
    description = "",
    weapons = {},
    command = "TEMPLATEJOB",
    max = 0,
    salary = GAMEMODE.Config.normalsalary,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Citizens",


    !! This is the part that you need to add to block bodygroups and skins !!
    If you don't add this part, the player will be able to change skins freely.
    skins = { 0, 1, 2 }, -- This is the list of skins that the player can use.

    If a bodygroup is not listed here or your do not add this part, the player will be able to change it freely.
    bodygroups = { -- This is the list of bodygroups that the player can use.
        ["Head"] = { 0, 3 }, -- This is the bodygroup name and the list of allowed values.
        ["Body"] = { 0, 1, 2 }, -- This is the bodygroup name and the list of allowed values.
    }
})
--]]


LDT_Closetter.Config.ConvertOldClosetterLocations = {
    ["superadmin"] = true
} -- These are the ranks that can run the command to convert the Arizard's Bodygroupr locations to this system. You can add more ranks if you want to.

-- The chat command to convert the Arizard's Bodygroupr locations to this system is "!closetter convert locations".

LDT_Closetter.Config.CanClosetBreak = true -- If this is set to false, the closets will not break when they reach 0 health.
LDT_Closetter.Config.ClosetHealth = 100 -- This is the health of the closet.

LDT_Closetter.Config.EnableRandomize = true -- If this is set to true, the randomize button will be displayed and enabled.
LDT_Closetter.Config.EnableCloning = true -- If this is set to true, the clone from other users feature will be displayed and enabled.

LDT_Closetter.Config.AdminMenuCommand = "!admin_closetter" -- This is the chat command to open the admin menu.

LDT_Closetter.Config.ClosetModel = "models/props_c17/FurnitureDresser001a.mdl" -- This is the model of the closet.
LDT_Closetter.Config.ClosetGroundOffset = 39 -- This is the offset of the closet from the ground. This is used to make the closet sit on the ground properly. Beacuse each model has different sizes, this value may need to be adjusted.


-- These are the colors for every element of the UI. Feel free to change them to your liking.
LDT_Closetter.Config.Red = Color(228, 58, 7)
LDT_Closetter.Config.RedHover = Color(255, 63, 5)
LDT_Closetter.Config.White = Color(255,255,255)
LDT_Closetter.Config.Grey = Color(47, 54, 64)
LDT_Closetter.Config.GreyHover = Color(57, 65, 77)
LDT_Closetter.Config.GreySecond = Color(31, 34, 41)
LDT_Closetter.Config.GreyTrans = Color(32, 33, 36, 200)
LDT_Closetter.Config.Blue = Color(0, 151, 230)
LDT_Closetter.Config.BlueSecond = Color(2, 161, 247)
LDT_Closetter.Config.ToolBlock = Color(0, 0, 0,220)
LDT_Closetter.Config.Black = Color(0, 0, 0)
LDT_Closetter.Config.BlackEntity = Color(0, 0, 0, 95)

-- These are the materials for every element of the UI. Feel free to change them to your liking.
LDT_Closetter.Materials = LDT_Closetter.Materials or {}
LDT_Closetter.Materials.ToolBG = Material("LDT_Closetter/display_bg_small.png", "ignorez")
LDT_Closetter.Materials.XIcon = Material("LDT_Closetter/x.png", "noclamp smooth")
LDT_Closetter.Materials.TrashCan = Material("LDT_Closetter/trash-can.png", "noclamp smooth")