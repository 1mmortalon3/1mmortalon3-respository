-- Which database mode to use.
-- Available modes: mysqloo, sqlite
LDT_Closetter.Config.DatabaseMode = "sqlite"

-- If mysqloo is enabled above, the login info for the MySQL server.
-- The tables will be created automatically.
LDT_Closetter.Config.DatabaseConfig = {
	host = "hostname",
	user = "username",
	password = "password",
	database = "dbname",
	port = 3306,
}