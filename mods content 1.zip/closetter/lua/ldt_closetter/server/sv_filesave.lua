-- Initialize the table to store closet locations.
LDT_Closetter.saveLocations = {
    closets = {},
}

-- Initialize the global presets table if it doesn't already exist.
LDT_Closetter.GlobalPresets = LDT_Closetter.GlobalPresets or {}

-- Load saved locations from a JSON file.
function LDT_Closetter.GetSaveLocations()
    if not file.Exists("ldt_closetter/save_locations.json", "DATA") then return end
    LDT_Closetter.saveLocations = util.JSONToTable(file.Read("ldt_closetter/save_locations.json", "DATA"))
end

-- Save the current locations to a JSON file.
function LDT_Closetter.SaveNewLocations()
    file.Write("ldt_closetter/save_locations.json", util.TableToJSON(LDT_Closetter.saveLocations))
end

-- Save a new closet location and execute a callback with the new closet ID and position.
function LDT_Closetter.SaveNewCloset(pos, angle, callback)
    local closetID = #LDT_Closetter.saveLocations.closets + 1
    
    table.insert(LDT_Closetter.saveLocations.closets, {
        pos = pos,
        angle = angle,
        map = LDT_Closetter.currentMap
    })

    LDT_Closetter.SaveNewLocations()
    callback(closetID, pos, angle)
end

-- Remove an item (closet) from the saved locations and execute a callback.
function LDT_Closetter.RemoveItem(id, type, callback)
    if type == "closet" then
        LDT_Closetter.saveLocations.closets[id] = nil
    end

    LDT_Closetter.SaveNewLocations()
    callback()
end

-- Saves new decal location for a specific decal
function LDT_Closetter.NewClosetLocation(closetID, pos, angle)
    if table.IsEmpty(LDT_Closetter.saveLocations) then return end
    if LDT_Closetter.saveLocations.closets[closetID] == nil then return end

    LDT_Closetter.saveLocations.closets[closetID].pos = pos
    LDT_Closetter.saveLocations.closets[closetID].angle = angle

    LDT_Closetter.SaveNewLocations()
end