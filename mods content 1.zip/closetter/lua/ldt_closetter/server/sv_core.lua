-- Initializes or retrieves the closets table.
LDT_Closetter.Closets = LDT_Closetter.Closets or {}

-- Spawns a closet entity with a specified ID, position, and angle.
function LDT_Closetter.SpawnCloset( id, pos, angle )
    local ent = ents.Create("ldt_closetter_closet")
    ent:SetPos( pos ) 
    ent:SetAngles(angle)
    ent:Spawn()
    ent:Activate()
    ent.closetID = id

    LDT_Closetter.Closets[id] = ent
end

-- Opens the closet UI for a player, sending available presets for their job.
function LDT_Closetter.OpenClosetUI(ply, closetID)
    local jobName = team.GetName(ply:Team())

    local globalPresets = LDT_Closetter.GetPresetsForJob(jobName)

    net.Start("LDT_Closetter.OpenClosetUI")
        net.WriteInt(closetID, 9)
        net.WriteEntity(ply)
        net.WriteUInt(#globalPresets, 8)
        for k, v in ipairs(globalPresets) do
            net.WriteUInt(v.PresetID, 22)
            net.WriteString(v.PresetName)
        end
    net.Send(ply)
end

-- Equips a global preset's model, skin, and bodygroups to a target player.
function LDT_Closetter.EquipeGlobalPreset(ply, targetPly, presetID) 
    local preset = LDT_Closetter.GetGlobalPreset(presetID)
    if not preset then return end

    local job = ply:getJobTable()
    targetPly:SetModel(preset.ModelName)
    if job.skins and not LDT_Closetter.Config.AdminRanks[LDT_Closetter.GetPlayerGroup(ply)] then 
        if job.skins[skinID+1] then
            targetPly:SetSkin(preset.SkinID)
        end
    else 
        targetPly:SetSkin(preset.SkinID)
    end

    ply.LDT_Closetter.LastJob = job.name
    ply.LDT_Closetter.LastPlayermodel = modelName
    
    for k, v in pairs(preset.Bodygroups) do
        if job.bodygroups and job.bodygroups[targetPly:GetBodygroupName(k)] and not LDT_Closetter.Config.AdminRanks[LDT_Closetter.GetPlayerGroup(ply)] then 
            if not job.bodygroups[targetPly:GetBodygroupName(k)][v+1] then
                continue
            end
        end

        targetPly:SetBodygroup(k, v)
    end

    timer.Simple(0.1, function()
        net.Start("LDT_Closetter.ModelChanged")
            net.WriteString(preset.ModelName)
        net.Send(ply)
    end)
end

-- Equips a local preset's model, skin, and bodygroups to a target player.
function LDT_Closetter.EquipeLocalPreset(ply, targetPly, modelName, skinID, bodygroups)
    targetPly:SetModel(modelName)

    local job = ply:getJobTable()
    if job.skins and not LDT_Closetter.Config.AdminRanks[LDT_Closetter.GetPlayerGroup(ply)] then 
        if job.skins[skinID+1] then
            targetPly:SetSkin(skinID)
        end
    else 
        targetPly:SetSkin(skinID)
    end

    ply.LDT_Closetter.LastJob = job.name
    ply.LDT_Closetter.LastPlayermodel = modelName
    
    for k, v in pairs(bodygroups) do
        if job.bodygroups and job.bodygroups[targetPly:GetBodygroupName(k)] and not LDT_Closetter.Config.AdminRanks[LDT_Closetter.GetPlayerGroup(ply)] then 
            if not job.bodygroups[targetPly:GetBodygroupName(k)][v+1] then
                continue
            end
        end

        targetPly:SetBodygroup(k, v)
    end

    timer.Simple(0.1, function()
        net.Start("LDT_Closetter.ModelChanged")
            net.WriteString(modelName)
        net.Send(ply)
    end)
end

-- Clones the model, skin, and bodygroups from one player to another.
function LDT_Closetter.ClonePreset(clonePly, ply)
    local modelName = clonePly:GetModel()
    local skinID = clonePly:GetSkin()
    local bodygroups = {}

    for i = 0, clonePly:GetNumBodyGroups() - 1 do
        bodygroups[i] = clonePly:GetBodygroup(i)
    end


    LDT_Closetter.EquipeLocalPreset(ply, ply, modelName, skinID, bodygroups)
end

-- Converts old Closetter locations to the new system.
function LDT_Closetter.ConvertOldClosetterLocations()
    if not file.Exists("bodyman/data.txt", "DATA") then return end

    local oldLocations = file.Read("bodyman/data.txt", "DATA")
    if not oldLocations then return end

    local locations = util.JSONToTable(oldLocations)
    if not locations then return end

    for k, v in pairs(locations.Closets) do
        if v.map != LDT_Closetter.currentMap then continue end

        LDT_Closetter.SaveNewCloset(v.pos, v.ang, function(closetID)
            local closet = ents.Create("ldt_closetter_closet")
            closet:SetPos( v.pos ) 
            closet:SetAngles(v.ang)
            closet:Spawn()
            closet:Activate()
            closet.closetID = closetID

            LDT_Closetter.Closets[closetID] = closet
        end )
    end
end

function LDT_Closetter.ValidatedGlobalPresetJob(targetPly, presetID)
    if not IsValid(targetPly) or not targetPly:IsPlayer() then return end
    local preset = LDT_Closetter.GetGlobalPreset(presetID)
    if not preset then return false end
    
    local job = targetPly:getJobTable()
    if job.name != preset.JobName then return false end

    return true
end

function LDT_Closetter.PlayerSpawnBodygroups(ply)
    if not IsValid(ply) or not ply:IsPlayer() then return end
    if not ply:Alive() then return end

    local job = ply:getJobTable()
    local skins = job.skins or {}
    local bodygroups = job.bodygroups or {}

    if ply.LDT_Closetter.LastJob and ply.LDT_Closetter.LastJob == job.name then
        if table.HasValue( ( type(job.model) == "table" and job.model or {} ), ( ply.LDT_Closetter.LastPlayermodel or "" ) ) then
            ply:SetModel(ply.LDT_Closetter.LastPlayermodel)
        end
    end

    local currentBodygroups = ply:GetBodyGroups()

    for k, v in pairs(currentBodygroups) do
        local name = k
        local id = ply:FindBodygroupByName( name )

        if id ~= -1 then
            local cur_group = ply:GetBodygroup( id )
            local allowed = false
            for k2, group in ipairs(bodygroups[name]) do
                if group == cur_group then
                    allowed = true
                    break
                end
            end

            if not allowed and next(bodygroups) ~= nil then
                ply:SetBodygroup( id, bodygroups[name][1] )
            end
        end
    end

    local allowed = false -- same as before
    
    if not job.skins then return end
    for k,v in pairs(job.skins) do
        local sk = v
        if sk == ply:GetSkin() then
            allowed = true 
            break;
        end
    end

    if not allowed and next(skins) ~= nil then
        ply:SetSkin( table.Random(skins) )
    end
end

net.Receive("LDT_Closetter.RandomizeBodygroups", function(len, ply)
    if not IsValid(ply) or not ply:IsPlayer() then return end
    if not LDT_Closetter.CooldownNetMessagesUser(ply, "RandomizeBodygroups") then return end

    local closetID = net.ReadInt(9)
    local newBodygroups = {}
    local count = net.ReadUInt(6)
    for i = 1, count do
        local bodygroupID = net.ReadUInt(6)
        local bodygroupValue = net.ReadUInt(6)
        newBodygroups[bodygroupID] = bodygroupValue
    end
    local targetPly = net.ReadEntity()

    if not IsValid(targetPly) then return end
    local job = targetPly:getJobTable()

    if targetPly != ply then 
        if not LDT_Closetter.Config.AdminRanks[LDT_Closetter.GetPlayerGroup(ply)] then return end
        for k, v in pairs(newBodygroups) do
            if job.bodygroups and job.bodygroups[targetPly:GetBodygroupName(k)] and not LDT_Closetter.Config.AdminRanks[LDT_Closetter.GetPlayerGroup(ply)] then 
                if not job.bodygroups[targetPly:GetBodygroupName(k)][v+1] then
                    continue
                end
            end
            targetPly:SetBodygroup(k, v)
        end
        return
    end

    if LDT_Closetter.Config.OpenFromContextMenuOverride
    or LDT_Closetter.Config.ContextMenuRanks and LDT_Closetter.Config.ContextMenuRanks[LDT_Closetter.GetPlayerGroup(ply)]
    or LDT_Closetter.Config.ContextMenuJobs and LDT_Closetter.Config.ContextMenuJobs[team.GetName(ply:Team())] then
        for k, v in pairs(newBodygroups) do
            if job.bodygroups and job.bodygroups[targetPly:GetBodygroupName(k)] and not LDT_Closetter.Config.AdminRanks[LDT_Closetter.GetPlayerGroup(ply)] then 
                if not job.bodygroups[targetPly:GetBodygroupName(k)][v+1] then
                    continue
                end
            end
            ply:SetBodygroup(k, v)
        end
        return
    end

    if not LDT_Closetter.Closets[closetID] then return end
    if not LDT_Closetter.CheckDistanceToCloset(ply, closetID) then return end

    for k, v in pairs(newBodygroups) do
        if job.bodygroups and job.bodygroups[targetPly:GetBodygroupName(k)] and not LDT_Closetter.Config.AdminRanks[LDT_Closetter.GetPlayerGroup(ply)] then 
            if not job.bodygroups[targetPly:GetBodygroupName(k)][v+1] then
                continue
            end
        end
        ply:SetBodygroup(k, v)
    end
end)

-- Retrieves users of the same job as the player and sends their SteamIDs
net.Receive("LDT_Closetter.GetJobUsers", function(len, ply)
    if not IsValid(ply) or not ply:IsPlayer() then return end
    if not LDT_Closetter.CooldownNetMessagesUser(ply, "GetJobUsers") then return end

    local jobName = team.GetName(ply:Team())
    local users = {}

    for k, v in ipairs(player.GetAll()) do
        if team.GetName(v:Team()) == jobName and v != ply then
            table.insert(users, v:SteamID64())
        end
    end

    net.Start("LDT_Closetter.GetJobUsersCallback")
        net.WriteUInt(#users, 8)
        for k, v in ipairs(users) do
            net.WriteString(v)
        end
    net.Send(ply)
end)

-- Allows the player to open the closet UI from anywhere.
net.Receive("LDT_Closetter.CanOpenClosetFromAnwhere", function( len, ply )
    if not IsValid(ply) or not ply:IsPlayer() then return end
    if not LDT_Closetter.CooldownNetMessagesUser(ply, "CanOpenClosetFromAnwhere") then return end
    
    if LDT_Closetter.Config.OpenFromContextMenuOverride then
        LDT_Closetter.OpenClosetUI(ply, -1)
        return 
    end
    
    if LDT_Closetter.Config.ContextMenuRanks and LDT_Closetter.Config.ContextMenuRanks[LDT_Closetter.GetPlayerGroup(ply)] then
        LDT_Closetter.OpenClosetUI(ply, -1)
        return
    end
    
    local jobName = team.GetName(ply:Team())
    if LDT_Closetter.Config.ContextMenuJobs and LDT_Closetter.Config.ContextMenuJobs[jobName] then
        LDT_Closetter.OpenClosetUI(ply, -1)
        return
    end
end)

-- Sets a bodygroup for a player based on network data.
net.Receive("LDT_Closetter.SetBodygroup", function( len, ply )
    if not IsValid(ply) or not ply:IsPlayer() then return end
    if not LDT_Closetter.CooldownNetMessagesUser(ply, "SetBodygroup") then return end

    local closetID = net.ReadInt(9)
    local bodygroupID = net.ReadUInt(6)
    local bodygroupValue = net.ReadUInt(6)
    local targetPly = net.ReadEntity()

    if not IsValid(targetPly) then return end

    local job = ply:getJobTable()

    if job.bodygroups and job.bodygroups[targetPly:GetBodygroupName(bodygroupID)] and not LDT_Closetter.Config.AdminRanks[LDT_Closetter.GetPlayerGroup(ply)] then 
        if not job.bodygroups[targetPly:GetBodygroupName(bodygroupID)][bodygroupValue+1] then
            return
        end
    end

    if targetPly != ply then 
        if not LDT_Closetter.Config.AdminRanks[LDT_Closetter.GetPlayerGroup(ply)] then return end

        targetPly:SetBodygroup(bodygroupID, bodygroupValue)
        ply.LDT_Closetter.LastJob = job.name

        return
    end

    if LDT_Closetter.Config.OpenFromContextMenuOverride 
    or LDT_Closetter.Config.ContextMenuRanks and LDT_Closetter.Config.ContextMenuRanks[LDT_Closetter.GetPlayerGroup(ply)]
    or LDT_Closetter.Config.ContextMenuJobs and LDT_Closetter.Config.ContextMenuJobs[team.GetName(ply:Team())] then 
        ply:SetBodygroup(bodygroupID, bodygroupValue)
        ply.LDT_Closetter.LastJob = job.name

        return
    end
    
    if not LDT_Closetter.Closets[closetID] then return end
    if not LDT_Closetter.CheckDistanceToCloset(ply, closetID) then return end
    ply:SetBodygroup(bodygroupID, bodygroupValue)
    ply.LDT_Closetter.LastJob = job.name
end)

-- Sets the model for a player based on network data.
net.Receive("LDT_Closetter.SetModel", function(len, ply)
    if not IsValid(ply) or not ply:IsPlayer() then return end
    if not LDT_Closetter.CooldownNetMessagesUser(ply, "SetModel") then return end

    local closetID = net.ReadInt(9)
    local model = net.ReadString()
    local targetPly = net.ReadEntity()
    
    if not IsValid(targetPly) then return end

    local job = ply:getJobTable()

    if not LDT_Closetter.CheckModelInJob(job.model, model) then return end

    if targetPly != ply then 
        if not LDT_Closetter.Config.AdminRanks[LDT_Closetter.GetPlayerGroup(ply)] then return end

        targetPly:SetModel(model)

        ply.LDT_Closetter.LastJob = job.name
        ply.LDT_Closetter.LastPlayermodel = model

        timer.Simple(0.1, function()
            net.Start("LDT_Closetter.ModelChanged")
                net.WriteString(model)
            net.Send(ply)
        end)
        return
    end
    if LDT_Closetter.Config.OpenFromContextMenuOverride 
    or LDT_Closetter.Config.ContextMenuRanks and LDT_Closetter.Config.ContextMenuRanks[LDT_Closetter.GetPlayerGroup(ply)]
    or LDT_Closetter.Config.ContextMenuJobs and LDT_Closetter.Config.ContextMenuJobs[team.GetName(ply:Team())] then 
        ply:SetModel(model)

        ply.LDT_Closetter.LastJob = job.name
        ply.LDT_Closetter.LastPlayermodel = model

        timer.Simple(0.1, function()
            net.Start("LDT_Closetter.ModelChanged")
                net.WriteString(model)
            net.Send(ply)
        end)

        return
    end
    
    if not LDT_Closetter.Closets[closetID] then return end
    if not LDT_Closetter.CheckDistanceToCloset(ply, closetID) then return end
    ply:SetModel(model)

    ply.LDT_Closetter.LastJob = job.name
    ply.LDT_Closetter.LastPlayermodel = model

    timer.Simple(0.1, function()
        net.Start("LDT_Closetter.ModelChanged")
            net.WriteString(model)
        net.Send(ply)
    end)
end)

-- Sets the skin for a player based on network data.
net.Receive("LDT_Closetter.SetSkin", function(len, ply)
    if not IsValid(ply) or not ply:IsPlayer() then return end
    if not LDT_Closetter.CooldownNetMessagesUser(ply, "SetSkin") then return end

    local closetID = net.ReadInt(9)
    local skinID = net.ReadUInt(6)
    local targetPly = net.ReadEntity()
    
    if not IsValid(targetPly) then return end

    local job = ply:getJobTable()

    if job.skins and not LDT_Closetter.Config.AdminRanks[LDT_Closetter.GetPlayerGroup(ply)] then 
        if not job.skins[skinID+1] then
            return
        end
    end

    if targetPly != ply then 
        if not LDT_Closetter.Config.AdminRanks[LDT_Closetter.GetPlayerGroup(ply)] then return end

        targetPly:SetSkin(skinID)

        ply.LDT_Closetter.LastJob = job.name

        return
    end

    if LDT_Closetter.Config.OpenFromContextMenuOverride 
    or LDT_Closetter.Config.ContextMenuRanks and LDT_Closetter.Config.ContextMenuRanks[LDT_Closetter.GetPlayerGroup(ply)]
    or LDT_Closetter.Config.ContextMenuJobs and LDT_Closetter.Config.ContextMenuJobs[team.GetName(ply:Team())] then 
        ply:SetSkin(skinID)
        ply.LDT_Closetter.LastJob = job.name

        return
    end
    
    if not LDT_Closetter.Closets[closetID] then return end
    if not LDT_Closetter.CheckDistanceToCloset(ply, closetID) then return end

    ply:SetSkin(skinID)
    ply.LDT_Closetter.LastJob = job.name
end)

-- Saves a global preset of bodygroups for a player.
net.Receive("LDT_Closetter.SaveGlobalPreset", function(len, ply)
    if not IsValid(ply) or not ply:IsPlayer() then return end
    if not LDT_Closetter.CooldownNetMessagesUser(ply, "SaveGlobalPreset") then return end
    if not LDT_Closetter.Config.AdminRanks[LDT_Closetter.GetPlayerGroup(ply)] then return end

    local presetName = net.ReadString()
    presetName = string.sub(presetName, 1, 20)
    local modelName = net.ReadString()
    local skinID = net.ReadUInt(6)
    local numberOfBodygroups = net.ReadUInt(8)
    local bodygroups = {}
    for i = 0, numberOfBodygroups do
        local bodygroupID = net.ReadUInt(8)
        local bodygroupValue = net.ReadUInt(6)

        bodygroups[bodygroupID] = bodygroupValue
    end

    local jobName = team.GetName(ply:Team())

    LDT_Closetter.SaveNewGlobalPreset(jobName, presetName, modelName, skinID, bodygroups, function()
        local preset = LDT_Closetter.GlobalPresets[#LDT_Closetter.GlobalPresets]
        if not preset then return end

        net.Start("LDT_Closetter.NewGlobalPresetSaved")
            net.WriteUInt(preset.PresetID, 22)
            net.WriteString(presetName)
        net.Send(ply)
    end)
end)

-- Loads a global preset of bodygroups for a player.
net.Receive("LDT_Closetter.LoadGlobalPreset", function(len, ply)
    if not IsValid(ply) or not ply:IsPlayer() then return end
    if not LDT_Closetter.CooldownNetMessagesUser(ply, "LoadGlobalPreset") then return end
    
    local presetID = net.ReadUInt(22)
    local closetID = net.ReadInt(9)
    local targetPly = net.ReadEntity()

    
    if not IsValid(targetPly) then return end
    if not LDT_Closetter.ValidatedGlobalPresetJob(ply, presetID) then return end
    if targetPly != ply then 
        if not LDT_Closetter.Config.AdminRanks[LDT_Closetter.GetPlayerGroup(ply)] then return end
        LDT_Closetter.EquipeGlobalPreset(ply, targetPly, presetID)
        return
    end

    if LDT_Closetter.Config.OpenFromContextMenuOverride 
    or LDT_Closetter.Config.ContextMenuRanks and LDT_Closetter.Config.ContextMenuRanks[LDT_Closetter.GetPlayerGroup(ply)]
    or LDT_Closetter.Config.ContextMenuJobs and LDT_Closetter.Config.ContextMenuJobs[team.GetName(ply:Team())] then 
        LDT_Closetter.EquipeGlobalPreset(ply, ply, presetID)
    end
    
    if not LDT_Closetter.Closets[closetID] then return end
    if not LDT_Closetter.CheckDistanceToCloset(ply, closetID) then return end

    LDT_Closetter.EquipeGlobalPreset(ply, ply, presetID)
end)

-- Handles the removal of a global preset by a player.
net.Receive("LDT_Closetter.RemoveGlobalPreset", function(len, ply)
    if not IsValid(ply) or not ply:IsPlayer() then return end
    if not LDT_Closetter.CooldownNetMessagesUser(ply, "RemoveGlobalPreset") then return end
    if not LDT_Closetter.Config.AdminRanks[LDT_Closetter.GetPlayerGroup(ply)] then return end

    local presetID = net.ReadUInt(22)
    LDT_Closetter.RemoveGlobalPreset(presetID, function()
        net.Start("LDT_Closetter.RemoveGlobalPresetCallback")
            net.WriteUInt(presetID, 22)
        net.Send(ply)
    end)
end)

-- Loads a user preset for bodygroups based on network data.
net.Receive("LDT_Closetter.LoadUserPreset", function(len, ply)
    if not IsValid(ply) or not ply:IsPlayer() then return end
    if not LDT_Closetter.CooldownNetMessagesUser(ply, "LoadUserPreset") then return end

    local jobName = team.GetName(ply:Team())

    local targetPly = net.ReadEntity()
    local closetID = net.ReadInt(9)
    local modelName = net.ReadString()
    local skinID = net.ReadUInt(6)
    local numberOfBodygroups = net.ReadUInt(8)
    local bodygroups = {}
    for i = 0, numberOfBodygroups do
        local bodygroupID = net.ReadUInt(6)
        local bodygroupValue = net.ReadUInt(6)
        
        bodygroups[bodygroupID] = bodygroupValue
    end

    
    if not IsValid(targetPly) then return end
    if targetPly != ply then 
        if not LDT_Closetter.Config.AdminRanks[LDT_Closetter.GetPlayerGroup(ply)] then return end
        LDT_Closetter.EquipeLocalPreset(ply, targetPly, modelName, skinID, bodygroups)
        return
    end
    
    if not LDT_Closetter.CheckModelInJob(LDT_Closetter.GetJobTable(jobName).model, modelName) then return end
    if LDT_Closetter.Config.OpenFromContextMenuOverride 
    or LDT_Closetter.Config.ContextMenuRanks and LDT_Closetter.Config.ContextMenuRanks[LDT_Closetter.GetPlayerGroup(ply)] 
    or LDT_Closetter.Config.ContextMenuJobs and LDT_Closetter.Config.ContextMenuJobs[team.GetName(ply:Team())] then
        LDT_Closetter.EquipeLocalPreset(ply, ply, modelName, skinID, bodygroups)
        return
    end
    
    if not LDT_Closetter.Closets[closetID] then return end
    if not LDT_Closetter.CheckDistanceToCloset(ply, closetID) then return end
    LDT_Closetter.EquipeLocalPreset(ply, ply, modelName, skinID, bodygroups)
end)

-- Clones bodygroups from one player to another based on network data.
net.Receive("LDT_Closetter.CloneBodygroups", function(len, ply)
    if not LDT_Closetter.Config.EnableCloning then return end
    if not IsValid(ply) or not ply:IsPlayer() then return end
    if not LDT_Closetter.CooldownNetMessagesUser(ply, "CloneBodygroups") then return end

    local closetID = net.ReadInt(9)
    local targetSteamID = net.ReadString()

    local targetPly = player.GetBySteamID64(targetSteamID)
    
    if not IsValid(targetPly) then return end
    if targetPly == ply then return end
    
    local plyJob = team.GetName(ply:Team())
    local targetJob = team.GetName(targetPly:Team())
    if targetJob != plyJob then return end
    
    if LDT_Closetter.Config.OpenFromContextMenuOverride 
    or LDT_Closetter.Config.ContextMenuRanks and LDT_Closetter.Config.ContextMenuRanks[LDT_Closetter.GetPlayerGroup(ply)]
    or LDT_Closetter.Config.ContextMenuJobs and LDT_Closetter.Config.ContextMenuJobs[team.GetName(ply:Team())] then
        LDT_Closetter.ClonePreset(targetPly, ply)
        return
    end
    
    if not LDT_Closetter.Closets[closetID] then return end
    if not LDT_Closetter.CheckDistanceToCloset(ply, closetID) then return end
    LDT_Closetter.ClonePreset(targetPly, ply)
end)

-- Receives the net message to delete all closets without saving the changes
net.Receive("LDT_Closetter.DeleteClosetsWithoutSaving", function(len, ply)
    if not IsValid(ply) or not ply:IsPlayer() then return end
    if not LDT_Closetter.CooldownNetMessagesUser(ply, "DeleteClosetsWithoutSaving") then return end
    if not LDT_Closetter.Config.AdminRanks[LDT_Closetter.GetPlayerGroup(ply)] then return end

    for k, v in pairs(LDT_Closetter.Closets) do
        v:Remove()  -- Remove each closet entity
    end

    LDT_Closetter.Closets = {}  -- Clear the closets table
end)

-- Receives the net message to load all closets for the current map
net.Receive("LDT_Closetter.LoadClosets", function(len, ply)
    if not IsValid(ply) or not ply:IsPlayer() then return end
    if not LDT_Closetter.CooldownNetMessagesUser(ply, "LoadClosets") then return end
    if not LDT_Closetter.Config.AdminRanks[LDT_Closetter.GetPlayerGroup(ply)] then return end

    for k, v in pairs(LDT_Closetter.Closets) do
        v:Remove()  -- Remove each closet entity
    end

    LDT_Closetter.Closets = {}  -- Clear the closets table

    for k, v in pairs(LDT_Closetter.saveLocations.closets) do
        if v.map == LDT_Closetter.currentMap then
            LDT_Closetter.SpawnCloset(k, v.pos, v.angle)  -- Spawn closet for the current map
        end
    end
end)

-- Receives the net message to edit another user's bodygroup presets
net.Receive("LDT_Closetter.EditOtherUser", function(len, ply)
    if not IsValid(ply) or not ply:IsPlayer() then return end
    if not LDT_Closetter.CooldownNetMessagesUser(ply, "EditOtherUser") then return end
    if not LDT_Closetter.Config.AdminRanks[LDT_Closetter.GetPlayerGroup(ply)] then return end

    local targetPly = net.ReadEntity()  -- Read the target player entity

    if not IsValid(targetPly) then return end

    local jobName = team.GetName(targetPly:Team())  -- Get the job name of the target player

    local globalPresets = LDT_Closetter.GetPresetsForJob(jobName)  -- Get the presets for the target player's job

    net.Start("LDT_Closetter.OpenClosetUI")
        net.WriteInt(-1, 9)
        net.WriteEntity(targetPly)
        net.WriteUInt(#globalPresets, 8)  -- Write the number of presets
        for k, v in ipairs(globalPresets) do
            net.WriteUInt(v.PresetID, 22)  -- Write the preset ID
            net.WriteString(v.PresetName)  -- Write the preset name
        end
    net.Send(ply)  -- Send the net message to the player
end)

-- Hook to initialize server-side settings after all entities have been initialized
hook.Add("InitPostEntity", "LDT_Closetter.ServerLoaded", function()
    if LDT_Closetter.Config.DatabaseMode == "mysqloo" then
        LDT_Closetter.ConnectToDatabase()  -- Connect to the MySQL database
    end

    LDT_Closetter.CreateDBTables()  -- Create necessary database tables
    LDT_Closetter.GetSavedPresets() -- Retrieve saved presets

    -- Ensure the directory for storing data exists
    if not file.Exists("ldt_closetter", "DATA") then
        file.CreateDir("ldt_closetter")
    end

    -- Ensure the save locations file exists
    if not file.Exists("ldt_closetter/save_locations.json", "DATA") then
        LDT_Closetter.SaveNewLocations()
    end
    LDT_Closetter.GetSaveLocations() -- Retrieve saved locations
    LDT_Closetter.GetSavedPresets() -- Retrieve saved presets again (potential redundancy)
    
    LDT_Closetter.currentMap = game.GetMap() -- Get the current map
    if table.IsEmpty(LDT_Closetter.saveLocations) then return end

    -- Spawn all closets that are saved for the current map
    for k, v in pairs(LDT_Closetter.saveLocations.closets) do
        if v.map == LDT_Closetter.currentMap then
            LDT_Closetter.SpawnCloset(k, v.pos, v.angle)
        end
    end
end)

hook.Add("PlayerInitialSpawn", "LDT_Closetter.PlayerInitialSpawn", function(ply)
    ply.LDT_Closetter = ply.LDT_Closetter or {}
    ply.LDT_Closetter.LastJob = nil
    ply.LDT_Closetter.LastPlayermodel = nil
end)

-- Hook to respawn all closets after the map has been cleaned up
hook.Add("PostCleanupMap", "LDT_Closetter.SpawnAllEntities", function()
    if table.IsEmpty(LDT_Closetter.saveLocations) then return end
    
    -- Spawn all closets that are saved for the current map
    for k, v in pairs(LDT_Closetter.saveLocations.closets) do
        if v.map == LDT_Closetter.currentMap then
            LDT_Closetter.SpawnCloset(k, v.pos, v.angle, v.color, v.scale, v.url)
        end
    end
end)

-- Hook to handle player chat commands for converting old bodygroupr locations and opening the admin menu
hook.Add("PlayerSay", "LDT_Closetter.ConvertClosetterLocations", function(ply, text)
    if LDT_Closetter.Config.ConvertOldClosetterLocations[LDT_Closetter.GetPlayerGroup(ply)] then
        if string.lower(text) == "!bodygroupr convert locations" or string.lower(text) == "/bodygroupr convert locations" then 
            LDT_Closetter.ConvertOldClosetterLocations()
        end
    end

    if not LDT_Closetter.Config.AdminRanks[LDT_Closetter.GetPlayerGroup(ply)] then return end
    if string.lower(text) != LDT_Closetter.Config.AdminMenuCommand then return end

    net.Start("LDT_Closetter.OpenAdminMenu")
    net.Send(ply)
end)

hook.Add("PlayerSay", "LDT_Closetter.OpenMenuUsingChatCommand", function(ply, text)
    if string.lower(text) != LDT_Closetter.Config.OpenClosetterCommand then return end
    if not LDT_Closetter.Config.EnableOpeningClosetterUsingCommand then return end

    if LDT_Closetter.Config.OpenFromContextMenuOverride 
    or LDT_Closetter.Config.ContextMenuRanks and LDT_Closetter.Config.ContextMenuRanks[LDT_Closetter.GetPlayerGroup(ply)]
    or LDT_Closetter.Config.ContextMenuJobs and LDT_Closetter.Config.ContextMenuJobs[team.GetName(ply:Team())] then 
        LDT_Closetter.OpenClosetUI(ply, -1)
        return
    end
end)

hook.Add("PlayerLoadout", "LDT_Closetter.PlayerLoadoutChanged", function(ply)
	LDT_Closetter.PlayerSpawnBodygroups(ply)
	timer.Simple(0,	function() LDT_Closetter.PlayerSpawnBodygroups( ply ) end)
end)

hook.Add("OnPlayerChangedTeam", "LDT_Closetter.PlayerSpawnBodygroupsOnPlayerChangedTeam", function( ply, before, after )
	LDT_Closetter.PlayerSpawnBodygroups( ply )
	timer.Simple(0, function()
		LDT_Closetter.PlayerSpawnBodygroups( ply )
	end)
end)

hook.Add("OnDarkRPVarChanged", "LDT_Closetter.PlayerSpawnBodygroupsOnDarkRPVarChanged", function()
	for k,v in ipairs(player.GetAll()) do
		LDT_Closetter.PlayerSpawnBodygroups( v )
	end
end)