-- Ensure the database mode is set to "sqlite" before proceeding.
if LDT_Closetter.Config.DatabaseMode ~= "mysqloo" then return end
local MySQLOO = require("mysqloo")

LDT_Closetter.DB_CLOSETTER = mysqloo.connect(LDT_Closetter.Config.DatabaseConfig.host, LDT_Closetter.Config.DatabaseConfig.user, LDT_Closetter.Config.DatabaseConfig.password, LDT_Closetter.Config.DatabaseConfig.database, LDT_Closetter.Config.DatabaseConfig.port)

function LDT_Closetter.ConnectToDatabase()
	LDT_Closetter.DB_CLOSETTER:setAutoReconnect(true)
	LDT_Closetter.DB_CLOSETTER:setMultiStatements(true)
	
	print("[CLOSETTER] Connecting to Database!")
	LDT_Closetter.DB_CLOSETTER.onConnected = function()
		print("[CLOSETTER] Database Connection Successful!")
	end
	LDT_Closetter.DB_CLOSETTER.onConnectionFailed = function(db,msg)
		print("[CLOSETTER] Database Connection failed!")
		print(msg)
	end

	LDT_Closetter.DB_CLOSETTER:connect()
end

-- Create database tables for storing global presets.
function LDT_Closetter.CreateDBTables()
    local query = LDT_Closetter.DB_CLOSETTER:query([[
		CREATE TABLE IF NOT EXISTS `LDT_Closetter_GlobalPresets` (
			`ID` int unsigned PRIMARY KEY AUTO_INCREMENT,
			`JobName` varchar(200) NOT NULL,
			`PresetName` varchar(200) NOT NULL,
            `ModelName` varchar(500) NOT NULL,
			`SkinID` int(11) NOT NULL,
            `Bodygroups` JSON NOT NULL
		);
    ]])
		
	query.onSuccess = function()
		print("[CLOSETTER] Successfully created MySQL tables.")
	end
	query:start()
end

-- Retrieve and load saved global presets from the database.
function LDT_Closetter.GetSavedPresets(callback)
    local query = LDT_Closetter.DB_CLOSETTER:query("SELECT * FROM LDT_Closetter_GlobalPresets")

    query.onSuccess = function(q, data)
        -- Clear the current global presets table.
        LDT_Closetter.GlobalPresets = {}
    
        if data then
            -- Iterate over the retrieved data and populate the global presets table.
            for k, v in pairs(data) do
                table.insert(LDT_Closetter.GlobalPresets, {
                    PresetID = tonumber(v.ID),
                    JobName = v.JobName,
                    PresetName = v.PresetName,
                    ModelName = v.ModelName,
                    SkinID = v.SkinID,
                    Bodygroups = util.JSONToTable(v.Bodygroups)
                })
            end
        end

        -- Execute the callback function if provided.
        if callback then
            callback()
        end
	end

    query:start()
end

-- Save a new global preset to the database.
function LDT_Closetter.SaveNewGlobalPreset(jobName, presetName, modelName, skinID, bodygroups, callback)
    -- Insert the new preset into the database.
    local query = LDT_Closetter.DB_CLOSETTER:query("INSERT INTO LDT_Closetter_GlobalPresets (JobName, PresetName, ModelName, SkinID, Bodygroups) VALUES ('" .. jobName .. "', '" .. presetName .. "', '" .. modelName .. "', " .. skinID .. ", '" .. util.TableToJSON(bodygroups) .. "')")

    query.onSuccess = function()
        -- Reload the global presets from the database.
        LDT_Closetter.GetSavedPresets(callback)
    end

    query:start()
end

-- Remove a global preset from the database.
function LDT_Closetter.RemoveGlobalPreset(presetID, callback)
    -- Delete the preset with the specified ID from the database.
    local query = LDT_Closetter.DB_CLOSETTER:query("DELETE FROM LDT_Closetter_GlobalPresets WHERE ID = " .. presetID)

    query.onSuccess = function()
        -- Reload the global presets from the database.
        LDT_Closetter.GetSavedPresets()
    
        -- Execute the callback function if provided.
        if callback then
            callback(presetID)
        end
    end

    query:start()
end