-- Ensure the database mode is set to "sqlite" before proceeding.
if LDT_Closetter.Config.DatabaseMode ~= "sqlite" then return end

-- Create database tables for storing global presets.
function LDT_Closetter.CreateDBTables()
    print("[LDT_CLOSETTER] Creating LDT_Closetter tables")
    sql.Query([[
        CREATE TABLE IF NOT EXISTS LDT_Closetter_GlobalPresets (
            ID INTEGER PRIMARY KEY, 
            JobName TEXT NOT NULL, 
            PresetName TEXT NOT NULL, 
            ModelName TEXT NOT NULL,
            SkinID INT NOT NULL,
            Bodygroups JSON NOT NULL
        );]])
end

-- Retrieve and load saved global presets from the database.
function LDT_Closetter.GetSavedPresets(callback)
    local data = sql.Query("SELECT * FROM LDT_Closetter_GlobalPresets")
    if data == false then return end

    -- Clear the current global presets table.
    LDT_Closetter.GlobalPresets = {}

    if data then
        -- Iterate over the retrieved data and populate the global presets table.
        for k, v in pairs(data) do
            table.insert(LDT_Closetter.GlobalPresets, {
                PresetID = tonumber(v.ID),
                JobName = v.JobName,
                PresetName = v.PresetName,
                ModelName = v.ModelName,
                SkinID = v.SkinID,
                Bodygroups = util.JSONToTable(v.Bodygroups)
            })
        end
    end

    -- Execute the callback function if provided.
    if callback then
        callback()
    end
end

-- Save a new global preset to the database.
function LDT_Closetter.SaveNewGlobalPreset(jobName, presetName, modelName, skinID, bodygroups, callback)
    -- Insert the new preset into the database.
    sql.Query("INSERT INTO LDT_Closetter_GlobalPresets (JobName, PresetName, ModelName, SkinID, Bodygroups) VALUES ('" .. jobName .. "', '" .. presetName .. "', '" .. modelName .. "', " .. skinID .. ", '" .. util.TableToJSON(bodygroups) .. "')")

    -- Reload the global presets from the database.
    LDT_Closetter.GetSavedPresets(callback)
end

-- Remove a global preset from the database.
function LDT_Closetter.RemoveGlobalPreset(presetID, callback)
    -- Delete the preset with the specified ID from the database.
    sql.Query("DELETE FROM LDT_Closetter_GlobalPresets WHERE ID = " .. presetID)

    -- Reload the global presets from the database.
    LDT_Closetter.GetSavedPresets()

    -- Execute the callback function if provided.
    if callback then
        callback(presetID)
    end
end