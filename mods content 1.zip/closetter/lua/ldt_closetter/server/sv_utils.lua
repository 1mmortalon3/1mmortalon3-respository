-- Register network strings for various functionalities.
util.AddNetworkString("LDT_Closetter.CanOpenClosetFromAnwhere")
util.AddNetworkString("LDT_Closetter.OpenClosetUI")
util.AddNetworkString("LDT_Closetter.SetBodygroup")
util.AddNetworkString("LDT_Closetter.SetModel")
util.AddNetworkString("LDT_Closetter.ModelChanged")
util.AddNetworkString("LDT_Closetter.SetSkin")
util.AddNetworkString("LDT_Closetter.SaveGlobalPreset")
util.AddNetworkString("LDT_Closetter.LoadGlobalPreset")
util.AddNetworkString("LDT_Closetter.NewGlobalPresetSaved")
util.AddNetworkString("LDT_Closetter.RemoveGlobalPreset")
util.AddNetworkString("LDT_Closetter.RemoveGlobalPresetCallback")
util.AddNetworkString("LDT_Closetter.LoadUserPreset")
util.AddNetworkString("LDT_Closetter.GetJobUsers")
util.AddNetworkString("LDT_Closetter.GetJobUsersCallback")
util.AddNetworkString("LDT_Closetter.CloneBodygroups")
util.AddNetworkString("LDT_Closetter.OpenAdminMenu")
util.AddNetworkString("LDT_Closetter.LoadClosets")
util.AddNetworkString("LDT_Closetter.DeleteClosetsWithoutSaving")
util.AddNetworkString("LDT_Closetter.EditOtherUser")
util.AddNetworkString("LDT_Closetter.RandomizeBodygroups")

-- Retrieve the job table for a given job name.
function LDT_Closetter.GetJobTable(jobName)
    local jobTable = nil
    
    -- Iterate through all defined jobs to find the one matching jobName.
    for _, teamInfo in pairs(RPExtraTeams or {}) do
        if teamInfo.name == jobName then
            jobTable = teamInfo
            break
        end
    end
    
    return jobTable
end

-- Check if a given model name is in a list of models.
function LDT_Closetter.CheckModelInJob(models, modelName)
    -- Iterate through the models list and check for a match.
    if isstring(models) then
        models = {models}
    end
    
    for k, v in ipairs(models) do
        if string.lower(v) == string.lower(modelName) then
            return true
        end
    end

    return false
end

-- Get the presets associated with a specific job.
function LDT_Closetter.GetPresetsForJob(jobName)
    local jobTable = LDT_Closetter.GetJobTable(jobName)

    -- Return an empty table if the job does not exist.
    if not jobTable then return {} end

    local presets = {}
    -- Iterate through all global presets to find those matching the job and model.
    for k, v in ipairs(LDT_Closetter.GlobalPresets) do
        if v.JobName == jobName and LDT_Closetter.CheckModelInJob(jobTable.model, v.ModelName) then
            table.insert(presets, v)
        end
    end
    
    return presets
end

-- Check if a player is within a certain distance to a closet.
function LDT_Closetter.CheckDistanceToCloset(ply, closetID)
    if not IsValid(ply) or not ply:IsPlayer() then return end
    if not LDT_Closetter.Closets[closetID] then return end

    local distance = ply:GetPos():Distance(LDT_Closetter.Closets[closetID]:GetPos())

    -- Return false if the distance is greater than 120 units.
    if distance > 120 then
        return false
    end

    return true
end

-- Retrieve a global preset by its ID.
function LDT_Closetter.GetGlobalPreset(presetID)
    -- Iterate through all global presets to find the one with the matching ID.
    for k, v in ipairs(LDT_Closetter.GlobalPresets) do
        if v.PresetID == presetID then
            return v
        end
    end

    return nil
end

-- Apply a cooldown for a specific network message for a player.
function LDT_Closetter.CooldownNetMessagesUser(ply, netMessageName)
    if not IsValid(ply) or not ply:IsPlayer() then return false end
    if ply.LDT_Closetter == nil then ply.LDT_Closetter = {} end

    local curtTime = CurTime()
    -- Check if the player has a cooldown for the specified message.
    if ply.LDT_Closetter[netMessageName] ~= nil then
        if ply.LDT_Closetter[netMessageName] > curtTime then return false end
    end

    -- Set the cooldown time for the network message.
    ply.LDT_Closetter[netMessageName] = curtTime + 0.25
    return true
end