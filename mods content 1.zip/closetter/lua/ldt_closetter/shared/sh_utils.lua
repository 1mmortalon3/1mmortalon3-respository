-- Returns the currently active language
function LDT_Closetter.GetLanguage(id)
    return LDT_Closetter.Language[LDT_Closetter.Config.Language][id]
end

-- Returns the correct User Group
function LDT_Closetter.GetPlayerGroup(ply)
    if SG then
        return ply:GetSecondaryUserGroup() or ply:GetUserGroup()
    else
        return ply:GetUserGroup()
    end
end
