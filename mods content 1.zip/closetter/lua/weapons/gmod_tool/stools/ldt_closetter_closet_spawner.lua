-- Ensure that this file is sent to the client.
AddCSLuaFile()

-- Define the category and properties for the tool.
TOOL.Category = "Closetter"
TOOL.Name = "Setup Closet"
TOOL.Author = "Lukyspore"

-- Client-side logic for setting up the tool's information.
if CLIENT then 
    TOOL.Information = {
        { name = "left" },
        { name = "right" }
    }

    -- Add language support for the tool's name and description.
    language.Add("tool.ldt_closetter_closet_spawner.name", LDT_Closetter.GetLanguage("ClosetToolName"))
    language.Add("tool.ldt_closetter_closet_spawner.desc", LDT_Closetter.GetLanguage("ToolDesc"))

    -- Add language support for the tool's usage instructions.
    language.Add("tool.ldt_closetter_closet_spawner.left", LDT_Closetter.GetLanguage("ToolLeft"))
    language.Add("tool.ldt_closetter_closet_spawner.right", LDT_Closetter.GetLanguage("ToolRight"))
end

-- Define a zero vector constant.
local zeroVector = Vector(0,0,0)

-- Define the behavior for left-clicking with the tool.
function TOOL:LeftClick(trace)
    local ply = self:GetOwner()
    if not IsValid(ply) or not ply:IsPlayer() then return end
    if not LDT_Closetter.Config.AdminRanks[LDT_Closetter.GetPlayerGroup(ply)] then return end

    local trace = util.TraceLine({
        start = ply:EyePos(),
        endpos = ply:EyePos() + ply:EyeAngles():Forward() * 300,
        filter = function(ent) if ent:GetClass() == "prop_physics" then return true end end
    })
    local pos = trace.HitPos + trace.HitNormal * 1 + Vector(0, 0, LDT_Closetter.Config.ClosetGroundOffset)
    local angSet = Angle(0, math.Round(ply:GetAimVector():Angle().Yaw) - 180, 0)
    
    if SERVER then
        LDT_Closetter.SaveNewCloset(pos, Angle(angSet, 0, 0), function(closetID)
            local closet = ents.Create("ldt_closetter_closet")
            closet:SetPos(pos) 
            closet:SetAngles(Angle(angSet, 0, 0))
            closet:Spawn()
            closet:Activate()
            closet.closetID = closetID

            LDT_Closetter.Closets[closetID] = closet
        end)
    end
end

-- Define the behavior for right-clicking with the tool.
function TOOL:RightClick(trace)
    local ply = self:GetOwner()
    if not IsValid(ply) or not ply:IsPlayer() then return end

    local trace = util.TraceLine({
        start = ply:EyePos(),
        endpos = ply:EyePos() + ply:EyeAngles():Forward() * 300,
        filter = function(ent) if ent:GetClass() == "prop_physics" then return true end end
    })
    local pos = trace.HitPos + trace.HitNormal * 1
    local angSet = Angle(0, math.Round(ply:GetAimVector():Angle().Yaw) - 180, 0)

    if SERVER then
        local ent = ply:GetEyeTrace().Entity
        if IsValid(ent) and ent:GetClass() == "ldt_closetter_closet" then
            LDT_Closetter.RemoveItem(ent.closetID, "closet", function()
                ent:Remove()
            end)
        end
    end
end 

-- Create a ghost entity for visualization on the client side.
function TOOL:CreateGhostEnt()
    if CLIENT then
        local ply = self:GetOwner()
        if not IsValid(LDT_Closetter.ClosetterClosetEnt) then
            LDT_Closetter.ClosetterClosetEnt = ClientsideModel(LDT_Closetter.Config.ClosetModel, RENDERGROUP_OPAQUE)
            LDT_Closetter.ClosetterClosetEnt:SetModel(LDT_Closetter.Config.ClosetModel)
            LDT_Closetter.ClosetterClosetEnt:SetAngles(Angle(0, 0, 0))
            LDT_Closetter.ClosetterClosetEnt:Spawn()
            LDT_Closetter.ClosetterClosetEnt:Activate()
            LDT_Closetter.ClosetterClosetEnt:SetRenderMode(RENDERMODE_TRANSALPHA)
            LDT_Closetter.ClosetterClosetEnt:SetColor(Color(255, 255, 255, 100))
        end
    end 
end

-- Periodically update the state of the tool.
function TOOL:Think()
    if CLIENT then
        local ply = self:GetOwner()
        if not IsValid(ply) and not ply:IsPlayer() then return end
        if not LDT_Closetter.Config.AdminRanks[LDT_Closetter.GetPlayerGroup(ply)] then return end

        local trace = util.TraceLine({
            start = LDT_Closetter.ply:EyePos(),
            endpos = LDT_Closetter.ply:EyePos() + LDT_Closetter.ply:EyeAngles():Forward() * 300,
            filter = function(ent) if ent:GetClass() == "prop_physics" then return true end end
        })
        
        local ent = LDT_Closetter.ply:GetEyeTrace().Entity
        local class = IsValid(ent) and ent:GetClass() or ""
        if class ~= "ldt_closetter_closet" then
            if IsValid(LDT_Closetter.ClosetterClosetEnt) then
                if ( !trace.Hit || IsValid( trace.Entity ) && ( trace.Entity:IsPlayer() || trace.Entity:GetClass() == "ldt_closetter_closet" ) ) then
                    LDT_Closetter.ClosetterClosetEnt:SetNoDraw(true)
                    return
                end
                if not isvector(self.LDTDecalsLerpPos) then self.LDTDecalsLerpPos = zeroVector end

                self.LDTDecalsLerpPos = Lerp(RealFrameTime()*40, self.LDTDecalsLerpPos, trace.HitPos+ trace.HitNormal * 1)
                
                local angSet = Angle(0, math.Round(LDT_Closetter.ply:GetAimVector():Angle().Yaw) - 180, 0)
                LDT_Closetter.ClosetterClosetEnt:SetPos(self.LDTDecalsLerpPos + Vector(0, 0, LDT_Closetter.Config.ClosetGroundOffset))
                LDT_Closetter.ClosetterClosetEnt:SetAngles( Angle(angSet, 0, 0))
                LDT_Closetter.ClosetterClosetEnt:SetModel(LDT_Closetter.Config.ClosetModel)
                LDT_Closetter.ClosetterClosetEnt:SetNoDraw(false)
            else 
                self:CreateGhostEnt() 
            end

            self:CreateGhostEnt() 
        else 
            if IsValid(LDT_Closetter.ClosetterClosetEnt) then 
                LDT_Closetter.ClosetterClosetEnt:Remove()
            end
        end
    end
end 

-- Clean up when the tool is holstered.
function TOOL:Holster()
    local ply = self:GetOwner()
    if not IsValid(ply) and not ply:IsPlayer() then return end
    if not LDT_Closetter.Config.AdminRanks[LDT_Closetter.GetPlayerGroup(ply)] then return end

    if CLIENT then
        if IsValid(LDT_Closetter.ClosetterClosetEnt) then 
            LDT_Closetter.ClosetterClosetEnt:Remove()
        end
    end
end

-- Draw the tool screen.
function TOOL:DrawToolScreen(w, h)
    surface.SetDrawColor(LDT_Closetter.Config.White)
    surface.SetMaterial(LDT_Closetter.Materials.ToolBG	)
    surface.DrawTexturedRect(0, 0, w, h)
    draw.SimpleText(LDT_Closetter.GetLanguage("ClosetterTitle"), "WorkSans3D2D30-Bold", w*.5, h*.1, LDT_Closetter.Config.TextSecond, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    draw.SimpleText(LDT_Closetter.GetLanguage("ClosetterText"), "WorkSans3D2D40-Bold", w*.5, h*.425, LDT_Closetter.Config.Text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    draw.SimpleText(LDT_Closetter.GetLanguage("ConfigurationText"), "WorkSans3D2D40-Bold", w*.5, h*.575, LDT_Closetter.Config.Text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end

-- Draw a custom HUD when using the tool.
function TOOL:DrawHUD()
    if not FPP then return end
    local ent = self.Owner:GetEyeTrace().Entity
    if not IsValid(ent) then return end
    if not ent:GetClass() == "ldt_closetter_closet" then return end
    if FPP.canTouchEnt(ent, "Toolgun") then return end
    
    draw.RoundedBox(0, 0, 0, LDT_Closetter.Config.Scrw, LDT_Closetter.Config.Scrh, LDT_Closetter.Config.ToolBlock)
    draw.SimpleText(LDT_Closetter.GetLanguage("ToolFPPPerms"), "WorkSans50-Bold", LDT_Closetter.Config.Scrw*0.5, LDT_Closetter.Config.Scrh*0.5, LDT_Closetter.Config.Red, TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM)
    draw.SimpleText(LDT_Closetter.GetLanguage("ToolFPPCheck"), "WorkSans40-Bold", LDT_Closetter.Config.Scrw*0.5, LDT_Closetter.Config.Scrh*0.5, LDT_Closetter.Config.White, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end