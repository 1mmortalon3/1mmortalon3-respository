local function AddFile(strPath,Include)
	local files, folders = file.Find(strPath.."*","LUA")
    
	for k,v in ipairs(files or {}) do
		if Include then
			include(strPath..v)
		else
			AddCSLuaFile(strPath..v)
		end
	end

	for k,v in ipairs(folders or {}) do 
		AddFile(strPath..v.."/",Include)
	end
end

local function LoadFiles()
	if SERVER then
		AddCSLuaFile("ldt_closetter/sh_config.lua")
		include("ldt_closetter/sh_config.lua")

		include("ldt_closetter/sv_mysql.lua")

		include("ldt_closetter/server/sv_utils.lua")
		include("ldt_closetter/server/sv_filesave.lua")
		include("ldt_closetter/server/sv_sqlitedb.lua")
		include("ldt_closetter/server/sv_mysqldb.lua")
		include("ldt_closetter/server/sv_core.lua")

		AddFile("ldt_closetter/shared/",true)
		AddFile("ldt_closetter/shared/",false)

		AddFile("ldt_closetter/client/",false)

	elseif CLIENT then
		include("ldt_closetter/sh_config.lua")
		
		AddFile("ldt_closetter/shared/",true)
		AddFile("ldt_closetter/client/",true)
	end
end

LoadFiles()