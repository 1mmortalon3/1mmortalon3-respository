AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

-- Initialize the entity and set the model
function ENT:Initialize()
    self:SetModel( LDT_Closetter.Config.ClosetModel )

	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:SetSolid(SOLID_VPHYSICS)
	self:SetUseType(SIMPLE_USE)
	local phys = self:GetPhysicsObject()

	if (phys:IsValid()) then
		phys:Wake()
		phys:EnableMotion(false)
	end

    self.closetID = 0
    self.health = LDT_Closetter.Config.ClosetHealth
end

function ENT:OnTakeDamage( dmginfo )
	self.health = self.health - dmginfo:GetDamage()

	if self.health <= 0 and LDT_Closetter.Config.CanClosetBreak then
		local ed = EffectData()
		ed:SetOrigin( self:GetPos() + self:OBBCenter() )
		util.Effect( "Explosion", ed )
		self:Remove()
	end
end

function ENT:Use(ply)
	if not IsValid(ply) or not ply:IsPlayer() then return end

    LDT_Closetter.OpenClosetUI(ply, self.closetID)
	
	self:EmitSound("doors/door1_move.wav", 100, math.random(75,100))
end

-- When the enitty is moved, update the decal location in the save file
hook.Add("PhysgunDrop", "LDT_Closetter.PhysgunDropEntity", function(ply, ent)
    if not LDT_Closetter.Config.AdminRanks[LDT_Closetter.GetPlayerGroup(ply)] then return end
    
    if ent:GetClass() == "ldt_closetter_closet" then
        LDT_Closetter.NewClosetLocation(ent.closetID, ent:GetPos(), ent:GetAngles())
    end
end)