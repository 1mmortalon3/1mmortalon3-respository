include("shared.lua")

local DrawPos = Vector(15, 0, 30)

function ENT:Initialize()
end

-- Draw the closet with the 3D2D displays
function ENT:Draw()
    if not LDT_Closetter.ply then return end
    if not IsValid( LDT_Closetter.ply ) then return end

    self:DrawModel()
    
    local ang = self:GetAngles()
    local secondAng = self:GetAngles()

    ang:RotateAroundAxis( secondAng:Up(), 90 )
	ang:RotateAroundAxis( secondAng:Right(), -90 )

    local intDist = LDT_Closetter.ply:GetPos():DistToSqr(self:GetPos())

	if intDist > 5 * 100000 then
		return
	end

    surface.SetFont("WorkSans3D2D150-Bold")
    local width, height = surface.GetTextSize(LDT_Closetter.GetLanguage("ClosetText"))
    surface.SetFont("WorkSans3D2D80")
    local width2, height2 = surface.GetTextSize(LDT_Closetter.GetLanguage("OpenClosetText"))

    local longestText = width
    if width2 > longestText then
        longestText = width2
    end

    local closetBoxWidth = math.Clamp(longestText + 100, 600, 900)

    cam.Start3D2D( self:LocalToWorld(DrawPos), ang, .05 )
        draw.RoundedBox( 8, - closetBoxWidth/2, -100, closetBoxWidth, 250, LDT_Closetter.Config.BlackEntity )
        draw.SimpleText( LDT_Closetter.GetLanguage("ClosetText"), "WorkSans3D2D150-Bold", 0, 0, LDT_Closetter.Config.White, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, LDT_Closetter.Config.Black )
        draw.SimpleText( LDT_Closetter.GetLanguage("OpenClosetText"), "WorkSans3D2D80", 0, 80, LDT_Closetter.Config.White, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, LDT_Closetter.Config.Black )
    cam.End3D2D()
end